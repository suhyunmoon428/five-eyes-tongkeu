/* ═══════════════════════════════════════════════════════════════
   /api/submit — 학생 활동 결과 저장 (Vercel Serverless Function)
   ───────────────────────────────────────────────────────────────
   브라우저에는 Supabase 키가 전혀 없습니다.
   학생 화면은 이 함수에 결과만 보내고, DB 접근은 서버가 담당합니다.

        학생 브라우저 ──▶ /api/submit ──▶ Supabase
                        (키 없음)        (키는 여기서만)

   service_role 대신 anon 키를 쓰고 RLS 의 INSERT 정책을 통과시키는
   방식도 가능하지만, 어차피 서버에서 호출하므로 권한이 명확한
   service_role 을 쓰고 이 함수가 유일한 입구가 되도록 했습니다.
   ═══════════════════════════════════════════════════════════════ */

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");

  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") {
    return res.status(405).json({ ok: false, error: "POST만 허용됩니다." });
  }

  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) {
    console.error("submit: Supabase 환경변수 누락");
    return res.status(500).json({
      ok: false,
      error: "SUPABASE_URL 또는 SUPABASE_SERVICE_ROLE_KEY가 설정되지 않았습니다.",
    });
  }

  let body = req.body;
  if (typeof body === "string") {
    try { body = JSON.parse(body); } catch (e) { body = null; }
  }
  if (!body || !body.sid || !body.name) {
    return res.status(400).json({ ok: false, error: "학번과 이름이 필요합니다." });
  }

  /* 서버에서 한 번 더 검증·절단한다.
     클라이언트가 보낸 값을 그대로 믿지 않는다. */
  const str = (v, n) => (v == null ? null : String(v).slice(0, n));
  const row = {
    sid: str(body.sid, 20),
    name: str(body.name, 20),
    nick: str(body.nick, 30),

    cleared_thinkers: body.clearedThinkers || {},
    conflict_title: str(body.conflictTitle, 100),
    conflict_level: Number.isFinite(body.conflictLevel) ? body.conflictLevel : null,
    tilt_value:
      typeof body.tilt === "number"
        ? Math.max(-100, Math.min(100, Math.round(body.tilt)))
        : null,
    stage3_text: str(body.stage3Text, 4000),

    level1: str(body.level1, 4),
    level2: str(body.level2, 4),
    record_text: str(body.recordText, 2000),
    praise_text: str(body.praiseText, 1000),

    full_messages: Array.isArray(body.messages) ? body.messages.slice(-200) : [],
    analytics: body.analytics || {},
    session_id: str(body.sessionId, 60),
  };

  try {
    const r = await fetch(`${url}/rest/v1/five_eyes_results`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: key,
        Authorization: `Bearer ${key}`,
        Prefer: "return=representation",
      },
      body: JSON.stringify(row),
    });

    const text = await r.text();
    if (!r.ok) {
      console.error("submit: Supabase insert 실패", r.status, text.slice(0, 300));
      return res.status(r.status).json({ ok: false, error: "저장에 실패했습니다." });
    }

    let saved = null;
    try { saved = JSON.parse(text); } catch (e) { saved = null; }
    return res.status(200).json({ ok: true, id: saved?.[0]?.id ?? null });
  } catch (err) {
    console.error("submit: 예외", String(err));
    return res.status(502).json({ ok: false, error: "저장 중 오류가 발생했습니다." });
  }
}

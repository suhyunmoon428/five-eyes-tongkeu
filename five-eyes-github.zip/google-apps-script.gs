/**
 * 「다섯 사람의 눈」 학생 응답 저장 스크립트
 *
 * 사용법
 *  1) 구글 스프레드시트를 새로 만든다
 *  2) 확장 프로그램 → Apps Script 를 열고, 기본 코드를 지운 뒤 이 파일 내용을 전부 붙여넣는다
 *  3) 저장(디스크 아이콘)
 *  4) 오른쪽 위 [배포] → [새 배포] → 톱니바퀴에서 [웹 앱] 선택
 *       설명: 통크 저장
 *       실행 계정: 나
 *       액세스 권한이 있는 사용자: 모든 사용자      ← 반드시 이걸로
 *  5) [배포] 를 누르고 권한 승인
 *       "이 앱은 확인되지 않았습니다" 창이 뜨면
 *       [고급] → [<프로젝트 이름>(으)로 이동] → [허용]
 *  6) 나온 주소(.../exec 로 끝남)를 복사해서
 *     five-eyes-tongkeu.jsx 맨 위 SHEET_ENDPOINT 에 붙여넣는다
 *
 * 시트는 자동으로 두 개가 만들어진다
 *   [응답]  학생이 한 말과 통크의 답을 한 줄씩 (진행 과정 전체)
 *   [결과]  활동을 마친 학생 한 명당 한 줄 (세특 문구 포함)
 *
 * ── 이미 배포해 두셨다면 ──────────────────────────────
 * 학생용 대시보드 통계 기능이 추가되어 이 파일이 바뀌었습니다.
 * Apps Script 편집기에서 기존 코드를 이 내용으로 전부 바꿔치기한 뒤,
 * [배포] → [배포 관리] → 연필 아이콘 → 버전: 새 버전 → [배포]
 * 를 눌러 다시 배포하면 됩니다. 주소(.../exec)는 그대로 유지되므로
 * SHEET_ENDPOINT를 다시 바꿀 필요는 없습니다.
 */

var TURN_HEADERS = [
  "시각", "세션", "학번", "이름", "닉네임", "단계",
  "사례", "고른 사상가", "학생이 쓴 설명", "통크의 답",
  "이번에 인정된 개념", "진행"
];

var RESULT_HEADERS = [
  "시각", "세션", "학번", "이름", "닉네임",
  "1단계 수준", "2단계 수준",
  "롤스", "노직", "매킨타이어", "샌델", "왈처",
  "2단계 주제", "3단계 나의 분배 기준",
  "세부능력 및 특기사항", "격려 문구", "저울(-100 자유주의 ~ 100 공동체주의)", "힌트 사용"
];

/* ── 학습분석 고도화(v2)로 추가된 시트 ───────────────────────
   [행동로그] 초 단위 미시 이벤트 원자료. 집계 기준이 바뀌어도
             이 원자료만 있으면 언제든 다시 계산할 수 있다.
   [학습분석] 세션당 1행. 교사 대시보드는 이 시트만 읽는다. */
var EVENT_HEADERS = [
  "시각", "세션", "학번", "이름", "경과(초)", "단계", "이벤트",
  "사례", "사상가", "지연(초)", "작성(초)", "누적턴", "누적번복", "상세"
];

var ANALYTICS_HEADERS = [
  "시각", "세션", "학번", "이름",
  "총 대화 턴", "선택 번복", "평균 지연(초)", "최장 지연(초)", "중앙 지연(초)",
  "제출 횟수", "평균 답변 길이", "힌트 사용",
  "도전 난이도", "도전 쟁점", "완수", "도전성 점수",
  "예시 총 사용", "전반 의존율", "후반 의존율", "소거폭",
  "최다 턴 사상가", "최다 턴", "최다 힌트 사상가",
  "알림 수", "알림 상세",
  "1단계 수준", "2단계 수준", "세특", "소거 시계열(JSON)", "사상가별 턴(JSON)"
];

/* ⚠️ 교사 대시보드 접근 코드 — 반드시 본인만 아는 값으로 바꾸세요.
   이 파일은 구글 시트 안에만 존재하고 GitHub에는 이 자리에 placeholder만
   올라갑니다. 아래 값을 그대로 두면 누구나 교사 화면에 들어올 수 있습니다. */
var TEACHER_KEY = "여기에_직접_정한_코드를_넣으세요";

function doPost(e) {
  /* 한 반이 동시에 제출해도 줄이 섞이지 않도록 잠금 */
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
  } catch (ignore) {}

  try {
    var data = JSON.parse(e.postData.contents);
    var ss = SpreadsheetApp.getActiveSpreadsheet();

    /* v2: 미시 행동 로그 묶음 */
    if (data.type === "events") {
      var es = getSheet_(ss, "행동로그", EVENT_HEADERS);
      var rows = (data.rows || []).map(function (v) {
        return [
          toKst_(v.ts), v.sessionId, v.sid, v.name,
          Math.round((v.elapsedMs || 0) / 1000), v.stage, v.type,
          v.caseId || "", v.thinkerId || "",
          v.dwellMs != null ? Math.round(v.dwellMs / 1000) : "",
          v.writeMs != null ? Math.round(v.writeMs / 1000) : "",
          v.turnCount != null ? v.turnCount : "",
          v.switchCount != null ? v.switchCount : "",
          compactDetail_(v)
        ];
      });
      if (rows.length) {
        es.getRange(es.getLastRow() + 1, 1, rows.length, EVENT_HEADERS.length).setValues(rows);
      }
      return json_({ ok: true, saved: rows.length });
    }

    /* v2: 세션 집계 + 알림 판정 결과 */
    if (data.type === "analytics") {
      var as = getSheet_(ss, "학습분석", ANALYTICS_HEADERS);
      var al = data.alerts || [];
      as.appendRow([
        toKst_(data.ts), data.session, data.sid, data.name,
        data.turnCount, data.switchCount,
        Math.round((data.avgDwellMs || 0) / 1000),
        Math.round((data.maxDwellMs || 0) / 1000),
        Math.round((data.medianDwellMs || 0) / 1000),
        data.submitCount, Math.round(data.avgAnswerLen || 0), data.hintUsed,
        data.challengeLevel, data.challengeTitle || "",
        data.challengeCompleted ? "완수" : "미완수", data.challengeScore,
        data.scaffoldTotal,
        pctText_(data.scaffoldEarlyRate), pctText_(data.scaffoldLateRate), pctText_(data.scaffoldFadeDelta),
        data.longestThinker || "", data.maxTurnsForThinker, data.hardestThinker || "",
        al.length,
        al.map(function (a) { return a.label + "(" + a.detail + ")"; }).join(" | "),
        data.level1 || "", data.level2 || "", data.record || "",
        JSON.stringify(data.scaffoldBuckets || []),
        JSON.stringify(data.turnsByThinker || {})
      ]);
      return json_({ ok: true });
    }

    if (data.type === "result") {
      var rs = getSheet_(ss, "결과", RESULT_HEADERS);
      rs.appendRow([
        toKst_(data.ts), data.session, data.sid, data.name, data.nick,
        data.level1, data.level2,
        data.rawls, data.nozick, data.macintyre, data.sandel, data.walzer,
        data.conflict, data.mine,
        data.record, data.praise, data.tilt, data.hints
      ]);
    } else {
      var ts = getSheet_(ss, "응답", TURN_HEADERS);
      ts.appendRow([
        toKst_(data.ts), data.session, data.sid, data.name, data.nick, data.stage,
        data.caseTitle, data.thinker, data.student, data.tongkeu,
        data.cleared, data.progress
      ]);
    }
    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  } finally {
    try { lock.releaseLock(); } catch (ignore) {}
  }
}

/* 배포 주소를 브라우저로 열었을 때 작동 확인용
   ?stats=1 로 요청하면 학생용 대시보드 집계를 돌려준다.
   이 함수는 개별 학생의 답변이나 이름을 절대 내보내지 않는다 —
   비율과 인원수만 계산해서 반환한다. */
function doGet(e) {
  if (e && e.parameter && e.parameter.stats === "1") {
    return statsForStudents_();
  }
  /* 교사 대시보드 전용 — 개인 식별 정보를 포함하므로 코드 검사를 통과해야 한다 */
  if (e && e.parameter && e.parameter.analytics === "1") {
    if (String(e.parameter.key || "") !== TEACHER_KEY) {
      return json_({ ok: false, error: "unauthorized" });
    }
    return analyticsForTeacher_();
  }
  return json_({ ok: true, message: "통크 저장 서버가 작동 중입니다." });
}

/* 최소 인원 미만이면 개인이 특정될 수 있으므로 비율을 아예 내려주지 않는다 */
var MIN_STUDENTS_FOR_STATS = 5;

function statsForStudents_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName("결과");
  if (!sh || sh.getLastRow() < 2) {
    return json_({ ok: true, total: 0, enough: false, minNeeded: MIN_STUDENTS_FOR_STATS });
  }

  var headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0];
  var tiltCol = headers.indexOf("저울(-100 자유주의 ~ 100 공동체주의)");
  var conflictCol = headers.indexOf("2단계 주제");
  if (tiltCol === -1) {
    return json_({ ok: true, total: 0, enough: false, minNeeded: MIN_STUDENTS_FOR_STATS });
  }

  var rows = sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn()).getValues();

  var total = 0;
  var lean = { lib: 0, mid: 0, com: 0 };            // 큰 갈래 3분류
  var band = { sLib: 0, lib: 0, mid: 0, com: 0, sCom: 0 }; // 세부 5구간
  var conflictCount = {};

  rows.forEach(function (row) {
    var raw = row[tiltCol];
    if (raw === "" || raw === null || typeof raw === "undefined") return; // 활동 미완료는 집계 제외
    var tilt = Number(raw);
    if (isNaN(tilt)) return;
    total++;

    if (tilt <= -60) band.sLib++;
    else if (tilt <= -20) band.lib++;
    else if (tilt < 20) band.mid++;
    else if (tilt < 60) band.com++;
    else band.sCom++;

    if (tilt < -35) lean.lib++;
    else if (tilt > 35) lean.com++;
    else lean.mid++;

    if (conflictCol !== -1) {
      var topic = row[conflictCol];
      if (topic) conflictCount[topic] = (conflictCount[topic] || 0) + 1;
    }
  });

  if (total < MIN_STUDENTS_FOR_STATS) {
    return json_({ ok: true, total: total, enough: false, minNeeded: MIN_STUDENTS_FOR_STATS });
  }

  return json_({
    ok: true,
    enough: true,
    total: total,
    lean: lean,       // { lib, mid, com } 인원수
    band: band,        // 5단계 세부 분포 인원수
    conflicts: conflictCount, // { "쟁점 제목": 인원수 }
  });
}

function getSheet_(ss, name, headers) {
  var sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.appendRow(headers);
    sh.setFrozenRows(1);
    sh.getRange(1, 1, 1, headers.length).setFontWeight("bold");
    sh.setColumnWidths(1, headers.length, 140);
  }
  return sh;
}

function toKst_(iso) {
  if (!iso) return new Date();
  var d = new Date(iso);
  return Utilities.formatDate(d, "Asia/Seoul", "yyyy-MM-dd HH:mm:ss");
}

/* 교사 대시보드가 읽는 집계본 — 학생 1명당 1개 객체 */
function analyticsForTeacher_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName("학습분석");
  if (!sh || sh.getLastRow() < 2) return json_({ ok: true, rows: [] });

  var head = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0];
  var C = {};
  head.forEach(function (h, i) { C[h] = i; });
  var vals = sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn()).getValues();

  /* 같은 학생이 여러 번 제출했으면 가장 마지막 세션만 남긴다 */
  var latest = {};
  vals.forEach(function (r) {
    var k = String(r[C["학번"]]) + "_" + String(r[C["이름"]]);
    latest[k] = r;
  });

  var rows = Object.keys(latest).map(function (k) {
    var r = latest[k];
    var num = function (h) { return Number(r[C[h]]) || 0; };
    var rate = function (h) { return (parseFloat(String(r[C[h]]).replace("%", "")) || 0) / 100; };
    var parse = function (h, dflt) {
      try { return JSON.parse(r[C[h]]); } catch (x) { return dflt; }
    };
    var metrics = {
      sessionId: r[C["세션"]], sid: r[C["학번"]], name: r[C["이름"]],
      turnCount: num("총 대화 턴"), switchCount: num("선택 번복"),
      switchPerCase: num("선택 번복") / Math.max(num("제출 횟수"), 1),
      avgDwellMs: num("평균 지연(초)") * 1000,
      maxDwellMs: num("최장 지연(초)") * 1000,
      medianDwellMs: num("중앙 지연(초)") * 1000,
      submitCount: num("제출 횟수"), avgAnswerLen: num("평균 답변 길이"),
      hintUsed: num("힌트 사용"),
      challengeLevel: num("도전 난이도"), challengeTitle: r[C["도전 쟁점"]],
      challengeCompleted: String(r[C["완수"]]) === "완수",
      challengeScore: num("도전성 점수"),
      scaffoldTotal: num("예시 총 사용"),
      scaffoldEarlyRate: rate("전반 의존율"),
      scaffoldLateRate: rate("후반 의존율"),
      scaffoldFadeDelta: rate("소거폭"),
      scaffoldBuckets: parse("소거 시계열(JSON)", []),
      turnsByThinker: parse("사상가별 턴(JSON)", {}),
      hintsByThinker: {},
      maxTurnsForThinker: num("최다 턴"),
      longestThinker: r[C["최다 턴 사상가"]],
      hardestThinker: r[C["최다 힌트 사상가"]],
      level1: r[C["1단계 수준"]], level2: r[C["2단계 수준"]], record: r[C["세특"]]
    };
    metrics.alerts = evaluateAlerts_(metrics);
    return metrics;
  });

  return json_({ ok: true, rows: rows, generatedAt: new Date().toISOString() });
}

/* 알림 규칙 — 프런트의 ALERT_RULES와 동일한 임계값을 서버에서도 재판정한다.
   시트를 직접 열어 보는 교사도 같은 기준을 보게 하기 위함이다. */
function evaluateAlerts_(m) {
  var out = [];
  if (m.hintUsed >= 3 && m.maxDwellMs >= 5 * 60 * 1000) {
    out.push({
      id: "cognitive_overload", label: "인지적 과부하 의심", severity: "high",
      detail: "힌트 " + m.hintUsed + "회 전부 소진 + 최장 " + Math.round(m.maxDwellMs / 60000) + "분 동안 입력을 시작하지 못함",
      action: (m.hardestThinker || "해당 사상가") + " 개념을 오프라인에서 먼저 재설명한 뒤, 같은 사례를 다시 적용해 보게 하세요."
    });
  }
  if (m.switchCount >= 5) {
    out.push({
      id: "trial_and_error", label: "개념 변별 곤란", severity: "high",
      detail: "사상가 선택을 " + m.switchCount + "회 번복함",
      action: "사상가 간 핵심 개념 대조표를 함께 만들어 보게 하세요. 개별 개념은 알지만 변별이 안 되는 상태입니다."
    });
  }
  if (m.scaffoldTotal >= 3 && m.scaffoldLateRate >= 0.6) {
    out.push({
      id: "scaffold_dependent", label: "스캐폴딩 미소거", severity: "mid",
      detail: "후반 시도의 " + Math.round(m.scaffoldLateRate * 100) + "%에서 문장 예시에 의존",
      action: "예시 없이 한 문장을 먼저 말해 보게 하는 구술 연습이 필요합니다."
    });
  }
  if (m.maxTurnsForThinker >= 6) {
    out.push({
      id: "turn_overrun", label: "되묻기 과다", severity: "mid",
      detail: (m.longestThinker || "특정 사상가") + " 하나를 설명하는 데 " + m.maxTurnsForThinker + "턴 소요",
      action: (m.longestThinker || "해당 사상가") + "의 사례 적용을 판서로 한 번 시범 보인 뒤 유사 사례를 주세요."
    });
  }
  if (m.submitCount >= 3 && m.medianDwellMs < 8000 && m.avgAnswerLen < 30) {
    out.push({
      id: "surface_response", label: "표면적 응답", severity: "mid",
      detail: "평균 " + Math.round(m.medianDwellMs / 1000) + "초 만에 평균 " + Math.round(m.avgAnswerLen) + "자로 응답",
      action: "사례를 소리 내어 읽고 근거 문장을 먼저 찾게 하세요."
    });
  }
  return out;
}

function pctText_(v) {
  return Math.round((Number(v) || 0) * 100) + "%";
}

/* 이벤트 상세를 한 칸에 담되 시트가 무거워지지 않게 요약 */
function compactDetail_(v) {
  var skip = { eventId: 1, sessionId: 1, sid: 1, name: 1, ts: 1, elapsedMs: 1, stage: 1,
               caseId: 1, thinkerId: 1, type: 1, dwellMs: 1, writeMs: 1, turnCount: 1, switchCount: 1 };
  var parts = [];
  for (var k in v) {
    if (skip[k] || v[k] === "" || v[k] == null) continue;
    parts.push(k + "=" + (typeof v[k] === "object" ? JSON.stringify(v[k]) : v[k]));
  }
  return parts.join("; ").slice(0, 400);
}

function json_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

// 통크(AI 튜터)의 브라우저 화면 대신 이 함수가 Claude API를 호출합니다.
// API 키는 Netlify 사이트 설정의 환경변수에만 있고, 이 함수를 거쳐 나가는
// 응답에는 절대 포함되지 않습니다 — 학생 브라우저에는 키가 보이지 않습니다.

const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";
const MODEL = "claude-sonnet-4-6";
const MAX_TOKENS_CAP = 1500; // 요청 남용을 막는 상한

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: cors, body: "" };
  }

  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers: cors, body: JSON.stringify({ error: "POST만 허용됩니다." }) };
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    console.error("ask-tongkeu: ANTHROPIC_API_KEY 환경변수가 비어 있음");
    return {
      statusCode: 500,
      headers: cors,
      body: JSON.stringify({ error: "ANTHROPIC_API_KEY가 설정되지 않았습니다. Netlify 사이트 환경변수를 확인하세요." }),
    };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch (e) {
    console.error("ask-tongkeu: 요청 본문 JSON 파싱 실패", String(e));
    return { statusCode: 400, headers: cors, body: JSON.stringify({ error: "잘못된 요청 형식입니다." }) };
  }

  const { system, messages, max_tokens } = payload;
  if (!Array.isArray(messages) || messages.length === 0) {
    console.error("ask-tongkeu: messages 누락 또는 빈 배열");
    return { statusCode: 400, headers: cors, body: JSON.stringify({ error: "messages가 필요합니다." }) };
  }

  try {
    const upstream = await fetch(ANTHROPIC_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: Math.min(Number(max_tokens) || 1000, MAX_TOKENS_CAP),
        system: typeof system === "string" ? system : "",
        messages,
      }),
    });

    const data = await upstream.json();

    if (!upstream.ok) {
      console.error("ask-tongkeu: Anthropic API 오류", upstream.status, JSON.stringify(data));
      return {
        statusCode: upstream.status,
        headers: cors,
        body: JSON.stringify({ error: data.error?.message || "Claude API 호출에 실패했습니다." }),
      };
    }

    return { statusCode: 200, headers: cors, body: JSON.stringify(data) };
  } catch (err) {
    console.error("ask-tongkeu: 업스트림 연결 실패", String(err));
    return { statusCode: 502, headers: cors, body: JSON.stringify({ error: "Claude API 연결에 실패했습니다: " + String(err) }) };
  }
};

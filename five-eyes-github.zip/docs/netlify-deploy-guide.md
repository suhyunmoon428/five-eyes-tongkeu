# 다섯 사람의 눈 — Netlify 배포 안내

이 zip 파일 그대로 Netlify에 올리면 됩니다. 안에는 웹앱 소스와,
Claude API 키를 안전하게 감춰 주는 서버리스 함수가 같이 들어 있습니다.

## 왜 함수가 따로 필요한가

이 앱은 학생이 뭔가 입력할 때마다 Claude(통크)를 호출합니다.
그런데 API 키를 화면 코드에 그대로 적으면 학생이 브라우저 개발자
도구로 그 키를 볼 수 있게 됩니다. 그래서 `netlify/functions/ask-tongkeu.js`
라는 작은 중개 서버를 하나 두고, 키는 Netlify에만 저장해 둡니다.
학생 화면은 이 중개 서버에만 말을 걸고, 중개 서버가 대신 Claude를
불러서 답을 받아 옵니다.

```
학생 브라우저 → /.netlify/functions/ask-tongkeu → Claude API
                (키 없음)              (키는 여기, Netlify 서버 안에서만)
```

구글 시트 저장 기능은 이것과 무관하게, 브라우저에서 곧바로
Apps Script 주소로 보냅니다. 이미 연결되어 있으니 그대로 둡니다.

---

## 1단계 · Netlify에 올리기

이 zip은 **소스 코드**입니다. Netlify가 이 소스를 받아서 직접
`npm install`과 `npm run build`를 돌려 화면을 만들어 냅니다.
그래서 올리는 방법에 따라 한 가지 주의할 점이 있습니다.

**추천 — Git 저장소를 거치는 방법 (가장 안전)**
1. 이 zip을 풀어서 GitHub(또는 GitLab)에 새 저장소로 올립니다
2. Netlify → **Add new site → Import an existing project** → 그 저장소 선택
3. Build command와 Publish directory는 `netlify.toml`에 이미 적혀 있어서
   자동으로 채워집니다 (`npm run build` / `dist`). 그대로 **Deploy** 누르면 끝입니다
4. 이후 저장소에 새로 올릴 때마다 자동으로 다시 빌드·배포됩니다

**zip을 바로 끌어다 놓는 방법 (Deploy manually)**
Netlify의 "Deploy manually"는 올린 파일을 **그대로** 배포하고, 빌드
과정(`npm run build`)을 돌리지 않습니다. 이 zip은 아직 빌드되지 않은
소스라서, 이 방식으로 그대로 올리면 빈 화면만 나옵니다.

zip을 바로 올리고 싶으시면, 이 안내서 맨 아래 **"로컬에서 미리
빌드해서 올리기"**를 따라 `dist` 폴더를 먼저 만든 뒤, 그 `dist`
폴더 안의 내용만 다시 압축해서 올려 주세요. 이 경우 서버리스
함수(`ask-tongkeu`)는 **Site configuration → Functions** 화면에서
`netlify/functions` 폴더를 별도로 한 번 더 업로드해 주셔야 합니다.
Git 연동 방식이 이런 수고 없이 한 번에 처리되므로, 가능하면 위
Git 방법을 권해 드립니다.

## 2단계 · Claude API 키 넣기 (반드시 필요)

이 단계를 건너뛰면 통크가 대답하지 못합니다.

1. 방금 만든 사이트 → **Site configuration → Environment variables**
2. **Add a variable**
3. Key: `ANTHROPIC_API_KEY`
   Value: 콘솔([console.anthropic.com](https://console.anthropic.com))에서
   발급받은 API 키 (`sk-ant-...`로 시작)
4. 저장 후 **Deploys → Trigger deploy → Deploy site**로 한 번 다시
   배포해야 반영됩니다. (환경변수는 다음 빌드부터 적용됩니다.)

## 3단계 · 도메인 연결

1. **Site configuration → Domain management → Add a domain**
2. 이미 갖고 계신 도메인을 입력합니다
3. 학교나 개인 도메인 등록기관(가비아, 카페24 등)에서 안내에 따라
   Netlify가 알려주는 네임서버 또는 DNS 레코드를 등록합니다
4. `www` 서브도메인까지 같이 쓰고 싶으면 같은 화면에서 추가할 수
   있습니다

DNS가 퍼지는 데 몇 분~몇 시간 걸릴 수 있습니다. 그동안은 처음의
`.netlify.app` 주소로도 정상 접속됩니다.

## 4단계 · 확인

배포된 주소로 들어가 학번·이름·닉네임을 입력하고 대화를 한 번
해 봅니다. 통크가 대답하면 정상입니다.

응답이 하나도 안 오면:
- **Site configuration → Environment variables**에서 `ANTHROPIC_API_KEY`
  철자와 값이 맞는지 확인
- **Deploys** 탭에서 마지막 배포가 초록색(성공)인지 확인
- 브라우저 개발자 도구(F12) → Network 탭에서
  `ask-tongkeu` 요청의 응답 내용을 확인

---

## 참고 · 이미 켜져 있는 것

- 구글 시트 자동 저장은 이미 연결되어 있습니다
  (`src/App.jsx` 맨 위 `SHEET_ENDPOINT`).
- 시트 쪽 설정을 바꾸고 싶으면 `google-apps-script.gs`를 구글
  스프레드시트의 Apps Script에 다시 붙여넣고 재배포하면 됩니다.

## 참고 · 학생용 "우리 반 생각 지도" 대시보드

첫 화면과 결과 화면에 **"친구들은 어떻게 생각할까?"** 버튼이 있습니다.
누르면 지금까지 활동을 마친 학생 전체의 자유주의/공동체주의 성향
비율을 보여줍니다. 학번·이름 등 개인정보나 누가 무슨 답을 했는지는
전혀 나오지 않고, 비율과 인원수만 나옵니다.

- 이미 학생 5명 이상이 활동을 마쳤다면 별도 설정 없이 바로 작동합니다.
- **이미 Apps Script를 배포해 두셨다면 한 번 갱신이 필요합니다.**
  이 대시보드는 시트 서버 쪽에 새로 추가된 집계 기능을 씁니다.
  Apps Script 편집기를 열어 기존 코드를 이번 `google-apps-script.gs`
  내용으로 통째로 바꿔 넣은 뒤, **배포 → 배포 관리 → 연필 아이콘 →
  버전: 새 버전 → 배포**를 눌러 다시 배포해 주세요. 주소(`.../exec`)는
  그대로 유지되므로 `SHEET_ENDPOINT`를 다시 바꿀 필요는 없습니다.
- 최소 인원(기본 5명) 미만이면 개인이 특정될 수 있어 비율을 아예
  보여주지 않습니다. 이 기준은 `google-apps-script.gs`의
  `MIN_STUDENTS_FOR_STATS` 값을 바꾸면 조정됩니다.

## 로컬에서 미리 빌드해서 올리기 (zip을 바로 쓰고 싶을 때)

컴퓨터에 [Node.js](https://nodejs.org) (18 버전 이상)를 설치한 뒤,
이 zip을 풀고 그 폴더에서:

```bash
npm install
npm run build
```

`dist`라는 폴더가 새로 생깁니다. **이 dist 폴더 안의 내용물**을
다시 zip으로 묶어서 Netlify의 Deploy manually에 올리면 화면은
바로 뜹니다. 다만 이 방법은 서버리스 함수가 함께 올라가지 않으므로,
Netlify 사이트의 **Functions** 메뉴에서 `netlify/functions` 폴더를
별도로 등록해 주셔야 통크가 응답합니다. Git 연동 방식을 쓰면 이
과정이 자동으로 한 번에 처리됩니다.

## 로컬에서 미리 보고 싶다면 (선택)

Netlify에 매번 안 올리고 컴퓨터에서 먼저 확인하고 싶으면:

```bash
npm install
npx netlify dev
```

`netlify dev`는 화면과 서버리스 함수를 함께 띄워 줘서, 실제 배포와
똑같이 동작을 확인할 수 있습니다. 이때도 `ANTHROPIC_API_KEY`를
로컬 환경변수로 넣어 줘야 합니다 (`netlify env:pull` 또는 `.env` 파일).

/* ═══════════════════════════════════════════════════════════════
   supabaseClient.js — 서버 경유 데이터 접근
   ───────────────────────────────────────────────────────────────
   ⚠️ 이 파일에는 Supabase URL 도, 키도 들어 있지 않습니다.

   Vite 는 VITE_ 접두사가 붙은 값을 빌드 결과물에 그대로 박아 넣습니다.
   그래서 브라우저에서 Supabase 를 직접 호출하지 않고, 서버리스 함수를
   거치도록 했습니다. 학생이 개발자 도구를 열어도 볼 수 있는 것은
   자기 자신이 보낸 결과뿐입니다.

        저장  브라우저 ──▶ /api/submit  ──▶ Supabase
        조회  브라우저 ──▶ /api/results ──▶ Supabase (교사 코드 검증)
   ═══════════════════════════════════════════════════════════════ */

/* 서버 함수를 통해 저장하므로 클라이언트 준비 여부를 따질 것이 없다.
   실제 연결 가능 여부는 저장을 시도할 때 응답으로 확인된다. */
export const supabaseReady = true;

/**
 * 3단계 완료 시점의 최종 결과를 저장한다.
 * 저장이 실패해도 학습 흐름은 막지 않는다(결과지 파일 저장으로 대체 가능).
 * @returns {Promise<{ok: boolean, error?: string, id?: number}>}
 */
export async function saveResult(payload) {
  try {
    const r = await fetch("/api/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const raw = await r.text();
    if (raw.trim().startsWith("<")) {
      return {
        ok: false,
        error: "서버 함수를 찾을 수 없습니다. 배포된 주소에서 시도해 주세요.",
      };
    }

    let d = null;
    try { d = JSON.parse(raw); } catch (e) { d = null; }
    if (!d) return { ok: false, error: "서버 응답을 읽지 못했습니다." };
    if (d.ok !== true) return { ok: false, error: d.error || "저장 실패" };

    return { ok: true, id: d.id };
  } catch (e) {
    return { ok: false, error: "network" };
  }
}

/**
 * 교사용 조회. 교사 코드 검증과 DB 접근 모두 서버에서 이루어진다.
 */
export async function fetchResultsForTeacher(teacherKey) {
  try {
    const r = await fetch(`/api/results?key=${encodeURIComponent(teacherKey || "")}`);
    const raw = await r.text();

    if (raw.trim().startsWith("<")) {
      return {
        ok: false,
        error: "서버 함수를 찾을 수 없습니다. 배포된 주소에서 시도해 주세요.",
      };
    }
    const d = JSON.parse(raw);
    if (d.ok !== true) {
      return {
        ok: false,
        error: d.error === "unauthorized" ? "unauthorized" : d.error || "조회 실패",
      };
    }
    return { ok: true, rows: d.rows || [] };
  } catch (e) {
    return { ok: false, error: "network" };
  }
}

/* ═══════════════════════════════════════════════════════════════
   analytics.js — 「다섯 사람의 눈」 학습분석 계측 코어
   ───────────────────────────────────────────────────────────────
   설계 원칙
   1) UI 코드와 분리한다. App.jsx는 "무슨 일이 일어났는지"만 알리고,
      집계·판정·전송은 전부 이 모듈이 책임진다.
   2) 계측 실패가 학습을 방해하면 안 된다. 모든 전송은 try/catch로
      감싸고 실패해도 학습 흐름은 그대로 진행된다.
   3) 원자료(event)와 집계값(metrics)을 함께 남긴다. 집계 기준이
      바뀌어도 원자료로 재계산할 수 있어야 한다.
   ═══════════════════════════════════════════════════════════════ */

/* ── 알림 규칙 (요구사항 4) ────────────────────────────────────
   교사가 오프라인 수업에서 즉시 개입할 지점을 잡아내는 규칙.
   규칙은 데이터가 아니라 '판정'이므로 한곳에 모아 두고,
   임계값은 교실 상황에 따라 조정할 수 있게 상수로 뺀다. */
export const ALERT_RULES = [
  {
    id: "cognitive_overload",
    label: "인지적 과부하 의심",
    severity: "high",
    // 힌트 3회 모두 소진 && 답변 지연 5분 이상
    test: (m) => m.hintUsed >= 3 && m.maxDwellMs >= 5 * 60 * 1000,
    describe: (m) =>
      `힌트 ${m.hintUsed}회 전부 소진 + 최장 ${Math.round(m.maxDwellMs / 60000)}분 동안 입력을 시작하지 못함`,
    prescribe: (m) =>
      `${m.hardestThinker || "해당 사상가"} 개념을 오프라인에서 먼저 재설명한 뒤, 같은 사례를 다시 적용해 보게 하세요.`,
  },
  {
    id: "trial_and_error",
    label: "개념 변별 곤란",
    severity: "high",
    // 사상가 선택을 계속 번복 = 누가 맞는지 구분하지 못함
    test: (m) => m.switchCount >= 5,
    describe: (m) => `사상가 선택을 ${m.switchCount}회 번복함 (사례별 평균 ${m.switchPerCase.toFixed(1)}회)`,
    prescribe: () =>
      "사상가 간 핵심 개념 대조표를 함께 만들어 보게 하세요. 개별 개념은 알지만 변별이 안 되는 상태입니다.",
  },
  {
    id: "scaffold_dependent",
    label: "스캐폴딩 미소거",
    severity: "mid",
    // 후반부에도 문장 완성 프롬프트 의존이 유지됨
    test: (m) => m.scaffoldTotal >= 3 && m.scaffoldLateRate >= 0.6,
    describe: (m) =>
      `후반 시도의 ${Math.round(m.scaffoldLateRate * 100)}%에서 문장 예시에 의존 (총 ${m.scaffoldTotal}회)`,
    prescribe: () =>
      "예시 없이 한 문장을 먼저 말해 보게 하는 구술 연습이 필요합니다. 아직 수동적 단계에 머물러 있습니다.",
  },
  {
    id: "turn_overrun",
    label: "되묻기 과다",
    severity: "mid",
    // 한 사상가를 통과하는 데 대화 턴이 과하게 소요됨
    test: (m) => m.maxTurnsForThinker >= 6,
    describe: (m) =>
      `${m.longestThinker || "특정 사상가"} 하나를 설명하는 데 ${m.maxTurnsForThinker}턴 소요`,
    prescribe: (m) =>
      `${m.longestThinker || "해당 사상가"}의 사례 적용을 판서로 한 번 시범 보인 뒤 유사 사례를 주세요.`,
  },
  {
    id: "surface_response",
    label: "표면적 응답",
    severity: "mid",
    // 지연 시간이 거의 없고 답변이 짧음 = 읽지 않고 찍는 패턴
    test: (m) => m.submitCount >= 3 && m.medianDwellMs < 8000 && m.avgAnswerLen < 30,
    describe: (m) =>
      `평균 ${Math.round(m.medianDwellMs / 1000)}초 만에 평균 ${Math.round(m.avgAnswerLen)}자로 응답`,
    prescribe: () =>
      "사례를 소리 내어 읽고 근거 문장을 먼저 찾게 하세요. 사례를 읽지 않고 응답하는 패턴입니다.",
  },
];

/* 도전성(요구사항 2) — 난이도 3단계 쟁점을 완수하면 가중 */
export const CHALLENGE_WEIGHT = { 1: 1, 2: 2, 3: 3 };

const nowMs = () => Date.now();
const uid = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

function median(arr) {
  if (!arr.length) return 0;
  const s = [...arr].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : Math.round((s[m - 1] + s[m]) / 2);
}

/* ═══════════════════════════════════════════════════════════════
   LearningTracker
   ═══════════════════════════════════════════════════════════════ */
export class LearningTracker {
  constructor({ endpoint, student, onFlush } = {}) {
    this.endpoint = endpoint || "";
    this.student = student || {};
    this.onFlush = onFlush || (() => {});
    this.sessionId = uid();
    this.startedAt = nowMs();

    this.events = [];   // 원자료 (초 단위 미시 로그)
    this.queue = [];    // 전송 대기열

    /* ── 요구사항 1: 턴 / 번복 / 지연 ── */
    this.turnCount = 0;            // AI 되묻기 ↔ 학생 답변 왕복 횟수
    this.switchCount = 0;          // 사상가 선택지 번복 횟수
    this.dwellSamples = [];        // 사례 노출 → 첫 입력까지 (ms)
    this.writeSamples = [];        // 첫 입력 → 제출까지 (ms)

    this._caseShownAt = null;      // 현재 사례가 화면에 뜬 시각
    this._firstKeyAt = null;       // 이번 응답의 첫 타건 시각
    this._pendingSelection = null; // 제출 전 잠정 선택된 사상가
    this._selectionTouched = false;

    /* ── 요구사항 3: 스캐폴딩 소거 ── */
    this.attemptSeq = 0;           // 제출 시도 일련번호 (1,2,3…)
    this.scaffoldSeries = [];      // [{seq, stage, thinker, used:0|1}]
    this._scaffoldArmed = false;   // 이번 응답에서 예시 버튼을 썼는가

    /* ── 요구사항 2: 도전성 ── */
    this.challenge = { picked: null, level: 0, completed: false, switched: 0 };

    /* ── 공통 ── */
    this.hintUsed = 0;
    this.turnsByThinker = {};      // {thinkerId: 턴 수}
    this.hintsByThinker = {};
    this.answerLens = [];
    this.currentThinker = null;
    this.currentCase = null;
    this.stage = 1;
  }

  /* ── 이벤트 기록 (모든 추적의 단일 통로) ── */
  log(type, payload = {}) {
    const ev = {
      eventId: uid(),
      sessionId: this.sessionId,
      sid: this.student.sid,
      name: this.student.name,
      ts: new Date().toISOString(),
      elapsedMs: nowMs() - this.startedAt,
      stage: this.stage,
      caseId: this.currentCase,
      thinkerId: this.currentThinker,
      type,
      ...payload,
    };
    this.events.push(ev);
    this.queue.push(ev);
    if (this.queue.length >= 8) this.flush();
    return ev;
  }

  setStage(s) {
    if (this.stage === s) return;
    this.log("stage_advance", { from: this.stage, to: s });
    this.stage = s;
  }

  /* ═══ 요구사항 1 ═══════════════════════════════════════════ */

  /** 사례 카드가 화면에 표시된 순간 — 지연 시간 측정의 기준점 */
  markCaseShown(caseId, meta = {}) {
    this.currentCase = caseId;
    this._caseShownAt = nowMs();
    this._firstKeyAt = null;
    this._pendingSelection = null;
    this._selectionTouched = false;
    this._scaffoldArmed = false;
    this.log("case_shown", { caseId, ...meta });
  }

  /** 사상가 선택 — 두 번째부터는 '번복'으로 집계 */
  markThinkerSelect(thinkerId) {
    const prev = this._pendingSelection;
    this.currentThinker = thinkerId;
    if (this._selectionTouched && prev && prev !== thinkerId) {
      this.switchCount += 1;
      this.log("thinker_switch", { from: prev, to: thinkerId, switchCount: this.switchCount });
    } else {
      this.log("thinker_select", { thinkerId });
    }
    this._pendingSelection = thinkerId;
    this._selectionTouched = true;
  }

  /** 입력창의 첫 타건 — 여기까지가 Dwell Time */
  markFirstKeystroke() {
    if (this._firstKeyAt) return;              // 응답당 1회만
    this._firstKeyAt = nowMs();
    const base = this._caseShownAt || this.startedAt;
    const dwellMs = this._firstKeyAt - base;
    this.dwellSamples.push(dwellMs);
    this.log("input_first_key", { dwellMs, dwellSec: Math.round(dwellMs / 1000) });
  }

  /** 답변 제출 */
  markSubmit({ text = "", thinkerId = null } = {}) {
    const t = nowMs();
    const writeMs = this._firstKeyAt ? t - this._firstKeyAt : 0;
    const dwellMs = this._firstKeyAt
      ? this._firstKeyAt - (this._caseShownAt || this.startedAt)
      : t - (this._caseShownAt || this.startedAt);

    if (!this._firstKeyAt) this.dwellSamples.push(dwellMs);  // 붙여넣기 등으로 타건이 없던 경우
    this.writeSamples.push(writeMs);
    this.answerLens.push(text.length);

    this.attemptSeq += 1;
    const th = thinkerId || this.currentThinker;

    /* 요구사항 3: 이번 시도에서 문장 예시를 썼는지 시계열에 적재 */
    this.scaffoldSeries.push({
      seq: this.attemptSeq,
      stage: this.stage,
      thinker: th,
      used: this._scaffoldArmed ? 1 : 0,
    });

    this.log("submit", {
      seq: this.attemptSeq,
      thinkerId: th,
      dwellMs,
      writeMs,
      answerLen: text.length,
      usedScaffold: this._scaffoldArmed,
      switchCountAtSubmit: this.switchCount,
    });

    this._firstKeyAt = null;
    this._scaffoldArmed = false;
    this._selectionTouched = false;
  }

  /** AI가 되물었을 때 — 턴 1 증가 */
  markAiTurn({ cleared = [], thinkerId = null } = {}) {
    this.turnCount += 1;
    const th = thinkerId || this.currentThinker;
    if (th) this.turnsByThinker[th] = (this.turnsByThinker[th] || 0) + 1;
    this.log("ai_turn", {
      turnCount: this.turnCount,
      thinkerId: th,
      passed: cleared.length > 0,
      cleared,
    });
  }

  /* ═══ 요구사항 3 ═══════════════════════════════════════════ */

  /** 문장 완성형 예시 버튼을 펼침 */
  markScaffoldOpen(kind) {
    this.log("scaffold_open", { kind });
  }

  /** 예시 문장을 실제로 입력창에 넣음 — 의존으로 집계 */
  markScaffoldInsert(kind, template) {
    this._scaffoldArmed = true;
    this.log("scaffold_insert", { kind, template: String(template).slice(0, 60) });
  }

  markHint() {
    this.hintUsed += 1;
    const th = this.currentThinker;
    if (th) this.hintsByThinker[th] = (this.hintsByThinker[th] || 0) + 1;
    this.log("hint_use", { hintUsed: this.hintUsed, thinkerId: th });
  }

  /* ═══ 요구사항 2 ═══════════════════════════════════════════ */

  markConflictSelect(conflictId, level, title) {
    if (this.challenge.picked && this.challenge.picked !== conflictId) {
      this.challenge.switched += 1;
    }
    this.challenge.picked = conflictId;
    this.challenge.level = level;
    this.log("conflict_select", { conflictId, level, title, switched: this.challenge.switched });
  }

  markConflictComplete() {
    this.challenge.completed = true;
    this.log("conflict_complete", {
      conflictId: this.challenge.picked,
      level: this.challenge.level,
      score: this.challengeScore(),
    });
  }

  /** 자기관리 역량(도전성) 점수 — 난이도 가중 × 완수 여부 */
  challengeScore() {
    const { level, completed } = this.challenge;
    if (!level) return 0;
    const w = CHALLENGE_WEIGHT[level] || 1;
    return completed ? w * 100 / 3 : (w * 100 / 3) * 0.4;  // 미완수는 40%만 인정
  }

  /* ═══ 집계 ═══════════════════════════════════════════════ */

  /** 스캐폴딩 소거 추이 — 전반/후반 의존율과 구간별 시계열 */
  scaffoldFade(bucketSize = 3) {
    const s = this.scaffoldSeries;
    const buckets = [];
    for (let i = 0; i < s.length; i += bucketSize) {
      const g = s.slice(i, i + bucketSize);
      buckets.push({
        label: `${i + 1}~${i + g.length}차`,
        from: i + 1,
        to: i + g.length,
        rate: g.reduce((a, b) => a + b.used, 0) / g.length,
        n: g.length,
      });
    }
    const half = Math.ceil(s.length / 2);
    const early = s.slice(0, half);
    const late = s.slice(half);
    const rate = (g) => (g.length ? g.reduce((a, b) => a + b.used, 0) / g.length : 0);
    return {
      buckets,
      series: s,
      earlyRate: rate(early),
      lateRate: rate(late),
      total: s.reduce((a, b) => a + b.used, 0),
      // 소거 폭: 양수면 후반으로 갈수록 예시를 덜 쓴 것 = 도약의 증거
      fadeDelta: rate(early) - rate(late),
    };
  }

  metrics() {
    const fade = this.scaffoldFade();
    const thinkerTurns = Object.entries(this.turnsByThinker);
    const worst = thinkerTurns.sort((a, b) => b[1] - a[1])[0];
    const hardHint = Object.entries(this.hintsByThinker).sort((a, b) => b[1] - a[1])[0];
    const caseCount = this.events.filter((e) => e.type === "case_shown").length || 1;

    return {
      sessionId: this.sessionId,
      sid: this.student.sid,
      name: this.student.name,
      nick: this.student.nick,
      durationMs: nowMs() - this.startedAt,

      // 요구사항 1
      turnCount: this.turnCount,
      switchCount: this.switchCount,
      switchPerCase: this.switchCount / caseCount,
      avgDwellMs: this.dwellSamples.length
        ? Math.round(this.dwellSamples.reduce((a, b) => a + b, 0) / this.dwellSamples.length)
        : 0,
      medianDwellMs: median(this.dwellSamples),
      maxDwellMs: this.dwellSamples.length ? Math.max(...this.dwellSamples) : 0,
      avgWriteMs: this.writeSamples.length
        ? Math.round(this.writeSamples.reduce((a, b) => a + b, 0) / this.writeSamples.length)
        : 0,
      submitCount: this.attemptSeq,
      avgAnswerLen: this.answerLens.length
        ? this.answerLens.reduce((a, b) => a + b, 0) / this.answerLens.length
        : 0,

      // 요구사항 2
      challengeLevel: this.challenge.level,
      challengeId: this.challenge.picked,
      challengeCompleted: this.challenge.completed,
      challengeScore: Math.round(this.challengeScore()),

      // 요구사항 3
      scaffoldTotal: fade.total,
      scaffoldEarlyRate: fade.earlyRate,
      scaffoldLateRate: fade.lateRate,
      scaffoldFadeDelta: fade.fadeDelta,
      scaffoldBuckets: fade.buckets,
      scaffoldSeries: fade.series,

      // 공통
      hintUsed: this.hintUsed,
      turnsByThinker: this.turnsByThinker,
      hintsByThinker: this.hintsByThinker,
      maxTurnsForThinker: worst ? worst[1] : 0,
      longestThinker: worst ? worst[0] : null,
      hardestThinker: hardHint ? hardHint[0] : null,
    };
  }

  /** 요구사항 4: 알림 판정 */
  alerts() {
    const m = this.metrics();
    return ALERT_RULES.filter((r) => r.test(m)).map((r) => ({
      id: r.id,
      label: r.label,
      severity: r.severity,
      detail: r.describe(m),
      action: r.prescribe(m),
    }));
  }

  /* ═══ 전송 ═══════════════════════════════════════════════ */

  async flush() {
    if (!this.endpoint || !this.queue.length) return;
    const batch = this.queue.splice(0, this.queue.length);
    try {
      await fetch(this.endpoint, {
        method: "POST",
        mode: "no-cors",
        headers: { "Content-Type": "text/plain;charset=utf-8" },
        body: JSON.stringify({ type: "events", session: this.sessionId, rows: batch }),
      });
      this.onFlush("ok", batch.length);
    } catch (e) {
      this.queue.unshift(...batch);   // 실패분은 되돌려 다음 기회에 재시도
      this.onFlush("fail", batch.length);
    }
  }

  /** 활동 종료 시 집계본 + 알림을 한 행으로 전송 */
  async finalize(extra = {}) {
    await this.flush();
    const payload = {
      type: "analytics",
      session: this.sessionId,
      ts: new Date().toISOString(),
      ...this.metrics(),
      alerts: this.alerts(),
      ...extra,
    };
    if (!this.endpoint) return payload;
    try {
      await fetch(this.endpoint, {
        method: "POST",
        mode: "no-cors",
        headers: { "Content-Type": "text/plain;charset=utf-8" },
        body: JSON.stringify(payload),
      });
      this.onFlush("ok", 1);
    } catch (e) {
      this.onFlush("fail", 1);
    }
    return payload;
  }
}

/* 브라우저 종료 시 잔여 큐를 흘려보내기 위한 헬퍼 */
export function attachUnloadFlush(tracker) {
  if (typeof window === "undefined") return () => {};
  const handler = () => {
    if (!tracker.endpoint || !tracker.queue.length) return;
    try {
      const blob = new Blob(
        [JSON.stringify({ type: "events", session: tracker.sessionId, rows: tracker.queue })],
        { type: "text/plain;charset=utf-8" }
      );
      navigator.sendBeacon(tracker.endpoint, blob);   // 언로드 중에도 살아남는 전송
      tracker.queue = [];
    } catch (e) { /* 무시 — 학습 종료를 막지 않는다 */ }
  };
  window.addEventListener("pagehide", handler);
  window.addEventListener("beforeunload", handler);
  return () => {
    window.removeEventListener("pagehide", handler);
    window.removeEventListener("beforeunload", handler);
  };
}

# 「다섯 사람의 눈」 v2 — 학습분석 기반 재설계

기존 대화형 튜터를 **역량 진단 도구 + 교사 DDDM 도구**로 확장한 설계안입니다.

---

## 1. 시스템 아키텍처

### 1.1 전체 구조

```
┌─────────────────────────── 학생 브라우저 ───────────────────────────┐
│                                                                      │
│   App.jsx (학습 화면)                                                 │
│      │                                                               │
│      ├─ 사용자 행동 발생 시 → analytics.js 로 통지만 한다            │
│      │    markCaseShown / markThinkerSelect / markFirstKeystroke     │
│      │    markSubmit / markHint / markScaffoldInsert / markAiTurn    │
│      │                                                               │
│      └─ LearningTracker (analytics.js)                               │
│            ├─ events[]   원자료 버퍼 (초 단위 미시 로그)              │
│            ├─ metrics()  집계 지표 계산                               │
│            ├─ alerts()   알림 규칙 판정                               │
│            └─ flush()    8건마다 배치 전송 / pagehide 시 sendBeacon   │
│                                                                      │
│   TeacherDashboard.jsx (교사 화면, ?teacher=1)                        │
└──────────────┬───────────────────────────────┬───────────────────────┘
               │ POST (학습 로그)               │ GET ?analytics=1&key=
               ▼                               ▼
     ┌─────────────────────────────────────────────────┐
     │  Google Apps Script Web App (doPost / doGet)     │
     │   · LockService 로 동시 제출 직렬화               │
     │   · evaluateAlerts_() 서버측 재판정                │
     │   · TEACHER_KEY 검사 후에만 개인 데이터 반환        │
     └──────────────────────┬──────────────────────────┘
                            ▼
     ┌─────────────────────────────────────────────────┐
     │  Google Sheets (4개 시트)                         │
     │   [응답] [결과] ← 기존                            │
     │   [행동로그] [학습분석] ← v2 신규                  │
     └─────────────────────────────────────────────────┘

     ┌─────────────────────────────────────────────────┐
     │  Netlify Function: ask-tongkeu                   │
     │   Claude API 키 은닉 (학습 대화 전용, 로그와 무관)  │
     └─────────────────────────────────────────────────┘
```

### 1.2 설계 원칙

| 원칙 | 이유 |
|---|---|
| **계측을 UI에서 분리** | App.jsx는 "무슨 일이 있었는지"만 알리고, 집계·판정·전송은 analytics.js가 전담. 지표 정의가 바뀌어도 UI를 건드리지 않는다. |
| **원자료와 집계본을 함께 저장** | `[행동로그]`에 초 단위 이벤트를 그대로 남긴다. 나중에 "지연 5분" 임계값을 3분으로 바꾸고 싶어도 원자료로 재계산할 수 있다. |
| **계측 실패가 학습을 막지 않음** | 모든 전송은 try/catch. 실패분은 큐에 되돌려 다음 기회에 재시도하고, 학생 화면은 그대로 진행된다. |
| **알림 규칙을 양쪽에서 동일하게 재판정** | 프런트 `ALERT_RULES`와 서버 `evaluateAlerts_()`가 같은 임계값을 쓴다. 시트를 직접 열어 보는 교사도 같은 기준을 본다. |
| **개인정보 접근 통제** | 학생용 집계(`?stats=1`)는 비율만, 교사용(`?analytics=1`)은 코드 검증 후에만 개인 데이터 반환. |

---

## 2. 데이터베이스 스키마

### 2.1 `[행동로그]` — 미시적 행동 원자료 (요구사항 1)

이벤트 1건 = 1행. 학생 한 명이 한 세션에서 60~150행 정도를 생성합니다.

```json
{
  "eventId":   "loyw3v28-h03rzq",
  "sessionId": "loyw3v28-ldzbvh",
  "sid": "10312", "name": "김통사",
  "ts": "2026-08-20T05:48:52.402Z",
  "elapsedMs": 360000,
  "stage": 1,
  "caseId": "rule",
  "thinkerId": "rawls",
  "type": "case_shown",

  "dwellMs": 361200,
  "writeMs": 40100,
  "turnCount": 3,
  "switchCount": 2,
  "usedScaffold": true,
  "answerLen": 87
}
```

**`type` 열거값**

| type | 발생 시점 | 채워지는 지표 |
|---|---|---|
| `case_shown` | 사례 카드 노출 | **Dwell 측정 기준점** |
| `thinker_select` | 사상가 첫 선택 | — |
| `thinker_switch` | 선택을 **바꿈** | **선택지 번복 +1** |
| `input_first_key` | 입력창 첫 타건 | **Dwell Time 확정** |
| `submit` | 답변 제출 | writeMs, answerLen, usedScaffold |
| `ai_turn` | 통크의 되묻기 | **대화 턴 +1** (사상가별 누적) |
| `hint_use` | 힌트 버튼 | 힌트 소진 카운트 |
| `scaffold_open` / `scaffold_insert` | 문장 예시 펼침/삽입 | **스캐폴딩 의존 플래그** |
| `conflict_select` / `conflict_complete` | 2단계 쟁점 선택/완수 | **도전성 지표** |
| `stage_advance` | 단계 전환 | 구간 분할 기준 |

### 2.2 `[학습분석]` — 세션 집계본 (요구사항 2·3·4)

학생 1명 = 1행. 교사 대시보드는 **이 시트만** 읽습니다.

```json
{
  "sessionId": "...", "sid": "10312", "name": "김통사",

  // ── 요구사항 1: 미시 행동 집계 ──
  "turnCount": 14,
  "switchCount": 6,
  "switchPerCase": 1.2,
  "avgDwellMs": 48000, "medianDwellMs": 31000, "maxDwellMs": 372000,
  "avgWriteMs": 52000, "submitCount": 9, "avgAnswerLen": 74,

  // ── 요구사항 2: 자기주도성(도전성) ──
  "challengeLevel": 3,
  "challengeId": "greenbelt",
  "challengeTitle": "개발 제한 구역",
  "challengeCompleted": true,
  "challengeScore": 100,

  // ── 요구사항 3: 스캐폴딩 점진적 소거 ──
  "scaffoldTotal": 5,
  "scaffoldEarlyRate": 0.80,
  "scaffoldLateRate": 0.00,
  "scaffoldFadeDelta": 0.80,
  "scaffoldBuckets": [
    { "label": "1~3차", "from": 1, "to": 3, "rate": 1.00, "n": 3 },
    { "label": "4~6차", "from": 4, "to": 6, "rate": 0.33, "n": 3 },
    { "label": "7~9차", "from": 7, "to": 9, "rate": 0.00, "n": 3 }
  ],
  "scaffoldSeries": [ { "seq": 1, "stage": 1, "thinker": "rawls", "used": 1 }, ... ],

  // ── 공통 ──
  "hintUsed": 3,
  "turnsByThinker": { "rawls": 2, "nozick": 6, "walzer": 3 },
  "hintsByThinker": { "nozick": 2, "walzer": 1 },
  "maxTurnsForThinker": 6, "longestThinker": "nozick",
  "hardestThinker": "nozick",

  // ── 요구사항 4: 알림 판정 결과 ──
  "alerts": [
    {
      "id": "cognitive_overload",
      "label": "인지적 과부하 의심",
      "severity": "high",
      "detail": "힌트 3회 전부 소진 + 최장 6분 동안 입력을 시작하지 못함",
      "action": "노직 개념을 오프라인에서 먼저 재설명한 뒤, 같은 사례를 다시 적용해 보게 하세요."
    }
  ]
}
```

### 2.3 알림 규칙표 (요구사항 4)

| id | 조건 | 등급 | 교육적 해석 |
|---|---|---|---|
| `cognitive_overload` | `hintUsed >= 3 && maxDwellMs >= 5분` | 🔴 | **요구사항의 지정 조건.** 발판을 다 써도 시작조차 못 함 → 개념 자체 미형성 |
| `trial_and_error` | `switchCount >= 5` | 🔴 | 사상가 선택을 반복 번복 → 개별 개념은 알지만 **변별 불가** |
| `scaffold_dependent` | `scaffoldTotal >= 3 && scaffoldLateRate >= 0.6` | 🟡 | 후반에도 예시 의존 → **수동적 단계에 정체** |
| `turn_overrun` | `maxTurnsForThinker >= 6` | 🟡 | 한 사상가에 되묻기 과다 → 특정 개념 병목 |
| `surface_response` | `submitCount >= 3 && medianDwell < 8초 && avgLen < 30자` | 🟡 | 사례를 읽지 않고 찍는 패턴 |

> **왜 `cognitive_overload`와 `surface_response`를 함께 두는가**
> 지연 시간은 단독으로 해석하면 오독됩니다. 길면 "고민한 것"일 수도, "못 한 것"일 수도 있습니다.
> 그래서 **힌트 소진(자원 고갈)** 과 결합할 때만 과부하로 판정하고,
> 반대로 지연이 **지나치게 짧으면서 답변도 짧으면** 별도 규칙으로 잡아냅니다.

### 2.4 도전성 점수 산식 (요구사항 2)

```
challengeScore = (난이도 가중 × 100 / 3) × (완수 ? 1.0 : 0.4)

난이도 가중: 1=1, 2=2, 3=3
```

| 선택 | 완수 | 점수 | 해석 |
|---|---|---|---|
| 난이도 3 (개발 제한 구역) | ○ | **100** | 어려운 것을 골라 끝까지 해냄 |
| 난이도 3 | × | **40** | 도전은 인정하되 완수 미달 |
| 난이도 1 (양심적 병역 거부) | ○ | **33** | 안전한 선택 |

미완수에도 40%를 주는 이유는, **도전 자체를 처벌하면 학생이 쉬운 것만 고르게 되기 때문**입니다. 난이도 3 미완수(40점)가 난이도 1 완수(33점)보다 높도록 설계했습니다.

---

## 3. 핵심 자바스크립트 로직

### 3.1 Dwell Time — 기준점과 확정 시점의 분리

```js
markCaseShown(caseId, meta = {}) {
  this.currentCase   = caseId;
  this._caseShownAt  = nowMs();   // ← 측정 시작
  this._firstKeyAt   = null;
  this._scaffoldArmed = false;
  this.log("case_shown", { caseId, ...meta });
}

markFirstKeystroke() {
  if (this._firstKeyAt) return;              // 응답당 정확히 1회
  this._firstKeyAt = nowMs();
  const dwellMs = this._firstKeyAt - (this._caseShownAt || this.startedAt);
  this.dwellSamples.push(dwellMs);
  this.log("input_first_key", { dwellMs, dwellSec: Math.round(dwellMs / 1000) });
}
```

React 연결부:

```jsx
<textarea value={draft}
  onChange={(e) => {
    if (!draft && e.target.value) trackerRef.current?.markFirstKeystroke();
    setDraft(e.target.value);
  }} />
```

`!draft && e.target.value` 조건이 핵심입니다. **빈 상태에서 값이 생긴 첫 순간**에만 발화하므로, 이후 타이핑에서는 중복 기록되지 않습니다.

### 3.2 선택지 번복 — 첫 선택과 변경의 구분

```js
markThinkerSelect(thinkerId) {
  const prev = this._pendingSelection;
  this.currentThinker = thinkerId;

  if (this._selectionTouched && prev && prev !== thinkerId) {
    this.switchCount += 1;                   // ← 번복만 카운트
    this.log("thinker_switch", { from: prev, to: thinkerId, switchCount: this.switchCount });
  } else {
    this.log("thinker_select", { thinkerId });
  }
  this._pendingSelection = thinkerId;
  this._selectionTouched = true;
}
```

`_selectionTouched` 플래그로 **첫 선택은 번복이 아님**을 보장하고, 같은 버튼 재클릭도 제외합니다. 제출 시 `markSubmit()`에서 플래그가 초기화되어 사례별로 다시 셉니다.

### 3.3 스캐폴딩 소거 시계열 (요구사항 3)

```js
markSubmit({ text = "", thinkerId = null } = {}) {
  ...
  this.attemptSeq += 1;
  this.scaffoldSeries.push({          // 시도 순번별로 의존 여부를 0/1로 적재
    seq: this.attemptSeq,
    stage: this.stage,
    thinker: thinkerId || this.currentThinker,
    used: this._scaffoldArmed ? 1 : 0,
  });
  this._scaffoldArmed = false;        // 다음 응답을 위해 해제
}

scaffoldFade(bucketSize = 3) {
  const buckets = [];
  for (let i = 0; i < this.scaffoldSeries.length; i += bucketSize) {
    const g = this.scaffoldSeries.slice(i, i + bucketSize);
    buckets.push({
      label: `${i + 1}~${i + g.length}차`,
      rate: g.reduce((a, b) => a + b.used, 0) / g.length,
      n: g.length,
    });
  }
  const half  = Math.ceil(this.scaffoldSeries.length / 2);
  const rate  = (g) => g.length ? g.reduce((a, b) => a + b.used, 0) / g.length : 0;
  const early = rate(this.scaffoldSeries.slice(0, half));
  const late  = rate(this.scaffoldSeries.slice(half));

  return { buckets, earlyRate: early, lateRate: late, fadeDelta: early - late };
}
```

`fadeDelta`가 **양수일수록 후반에 예시를 덜 쓴 것**이며, 이것이 곧 ICAP의 수동적(Passive) → 상호작용적(Interactive) 도약의 증거로 쓰입니다.

**검증 결과** (시뮬레이션 시나리오 B):
```
구간별 의존율: 1~3차 100% → 4~6차 33% → 7~9차 0%
전반 80% → 후반 0% | 소거폭 80%p | 알림: 없음(정상)
```

### 3.4 2단계 난이도 메타 (요구사항 2)

```js
const CONFLICTS = [
  { id: "conscience", title: "양심적 병역 거부", level: 1, levelName: "기본",
    why: "두 입장이 교과서에 또렷하게 대비돼 있어요. 처음 도전하기 좋아요.", est: "약 5분", ... },
  { id: "excess",     title: "초과 이윤세",     level: 2, levelName: "도전",
    why: "'정당하게 번 돈'의 기준부터 따져야 해서 한 번 더 생각하게 돼요.", est: "약 8분", ... },
  { id: "greenbelt",  title: "개발 제한 구역",   level: 3, levelName: "심화 쟁점",
    why: "재산권·환경·다음 세대까지 얽혀 있어 사상가 두 명 이상을 엮어야 해요.", est: "약 12분", ... },
];
```

UI 렌더링:

```jsx
<button className={`cfr lv${c.level}`} onClick={() => chooseConflict(c)}>
  <div className="cfr-lv">
    <span className="flames">{"🔥".repeat(c.level)}</span>
    <span className={`lvname lv${c.level}`}>{c.levelName}</span>
    {c.level === 3 && <span className="badge-adv">심화 쟁점</span>}
    <span className="est">{c.est}</span>
  </div>
  <b>{c.title}</b>
  <span>{c.short}</span>
  <em className="why">{c.why}</em>
</button>
```

`why`와 `est`를 함께 보여 주는 이유는, 난이도 표기만 있으면 학생이 **무조건 쉬운 것을 고르기** 때문입니다. "무엇이 어려운지"와 "얼마나 걸리는지"를 알려 주면 도전이 계산 가능한 선택이 됩니다.

### 3.5 언로드 시 데이터 유실 방지

```js
export function attachUnloadFlush(tracker) {
  const handler = () => {
    if (!tracker.endpoint || !tracker.queue.length) return;
    const blob = new Blob([JSON.stringify({ type: "events", rows: tracker.queue })],
                          { type: "text/plain;charset=utf-8" });
    navigator.sendBeacon(tracker.endpoint, blob);   // 탭이 닫히는 중에도 전송됨
    tracker.queue = [];
  };
  window.addEventListener("pagehide", handler);
  window.addEventListener("beforeunload", handler);
}
```

학생이 종료 버튼 없이 탭을 닫는 것이 일반적이므로, 일반 `fetch`로는 마지막 몇 건이 유실됩니다. `sendBeacon`은 문서 언로드 중에도 보장 전송됩니다.

---

## 4. 교사 대시보드 컴포넌트 구조

```
TeacherDashboard
├── 인증 게이트 (TEACHER_KEY 검증 후 데이터 로드)
│
├── <section className="kpi">           학급 KPI 6칸
│      🔴 즉시 개입 필요 / 제출 학생 / 📈 예시 의존 감소
│      🔥 심화 완수 / 평균 대화 턴 / 평균 응답 지연
│
├── <section className="panel">         🧭 다음 차시에 다시 다룰 개념
│      사상가별 평균 턴 수 가로 막대 (5턴↑ 빨강 / 3.5턴↑ 주황)
│      → "학급 전체가 노직에서 막혔다"를 한눈에
│
├── <div className="filters">           🚨 개입 필요 | 전체 | 🔥 심화 선택
│
└── <StudentCard> ×N                    개입 필요 학생이 항상 최상단
     ├── 헤더: 이름 + 🔴/🟡 배지 + 🔥 심화 완수 + 📈 의존 감소
     ├── 지표 5칸: 대화 턴 / 선택 번복 / 최장 지연 / 힌트 / 도전성
     └── 펼침 영역
          ├── 🚨 <AlertCard>       [무슨 일이] [근거 수치] [처방]
          ├── 📊 <FadeChart>       SVG 꺾은선 + 학급 평균 점선 비교
          ├── 🧠 사상가별 인지 부하  5칸 히트맵 (6턴↑ 빨강)
          └── 🔥 2단계 도전 선택     난이도 · 완수 여부
```

### 4.1 알림 카드가 항상 3줄인 이유

```jsx
<div className="alert-card high">
  <div className="ac-head">🔴 즉시 개입 · 인지적 과부하 의심</div>
  <div className="ac-detail">📉 힌트 3회 전부 소진 + 최장 6분간 입력 시작 못 함</div>
  <div className="ac-action"><b>처방</b> 노직 개념을 오프라인에서 먼저 재설명한 뒤,
                              같은 사례를 다시 적용해 보게 하세요.</div>
</div>
```

진단(`detail`)만 있고 처방(`action`)이 없으면 교사는 "그래서 뭘 하지?"에서 멈춥니다. **DDDM의 목적은 데이터 제공이 아니라 다음 행동 결정**이므로, 규칙마다 `prescribe()` 함수를 필수로 정의했습니다.

### 4.2 정렬 우선순위

```js
const score = (r) => {
  const A = r.alerts || [];
  return A.filter(a => a.severity === "high").length * 10 + A.length;
};
list.sort((a, b) => score(b) - score(a));
```

교사가 이 화면을 여는 시점은 대개 **다음 차시 직전 5분**입니다. 잘한 학생 통계는 아래로 내리고, 개입이 필요한 학생을 무조건 위로 올립니다.

### 4.3 차트를 SVG로 직접 그린 이유

Recharts 등을 쓰면 번들이 커지고 학교 네트워크에서 로딩이 느려집니다. 꺾은선 하나에 의존성을 추가할 이유가 없어 `<path>` 로 직접 그렸습니다.

```jsx
const x = (i) => pad.l + (i / (buckets.length - 1)) * w;
const y = (r) => pad.t + h - r * h;
const line = pts.map((p, i) => `${i ? "L" : "M"}${p[0]},${p[1]}`).join(" ");
```

학급 평균 점선을 함께 그려서 **"이 학생만 그런 건지, 우리 반 전체가 그런 건지"** 를 즉시 판단할 수 있게 했습니다.

---

## 5. 배포 시 확인 사항

1. **Apps Script 재배포 필수**
   `[행동로그]`·`[학습분석]` 시트와 `?analytics=1` API가 추가되었습니다.
   Apps Script 편집기에서 코드 교체 → 배포 → 배포 관리 → 새 버전 → 배포.
   주소(`/exec`)는 유지되므로 `SHEET_ENDPOINT`는 그대로 둡니다.

2. **`TEACHER_KEY` 변경**
   `google-apps-script.gs` 상단의 `var TEACHER_KEY = "tongkeu2026";` 를 반드시 바꿔 주세요.
   교사 대시보드는 `주소/?teacher=1` 로 접속합니다.

3. **시트 용량**
   학생 1명당 행동로그 60~150행이 쌓입니다. 30명 × 5개 반 = 약 2만 행으로,
   구글 시트 한도(500만 셀) 대비 여유롭습니다. 학기 단위로 시트를 분리하면 조회가 빨라집니다.

4. **개인정보**
   `[행동로그]`·`[학습분석]`에는 학번·이름이 포함됩니다. 스프레드시트 공유 범위를 교사 계정으로 한정하고, 활동 시작 화면에 수집 항목을 안내해 주세요.

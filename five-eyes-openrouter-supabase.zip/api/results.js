/* ═══════════════════════════════════════════════════════════════
   /api/results — 교사용 제출 현황 조회 (Vercel Serverless Function)
   ───────────────────────────────────────────────────────────────
   학생용 anon key 는 RLS 정책상 SELECT 가 막혀 있습니다.
   교사 조회는 RLS 를 우회하는 service_role 키가 필요한데, 이 키가
   브라우저로 내려가면 누구나 전체 데이터를 읽을 수 있게 됩니다.
   그래서 이 함수가 서버에서 대신 조회하고, 교사 코드를 검증합니다.
   ═══════════════════════════════════════════════════════════════ */

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");

  if (req.method === "OPTIONS") return res.status(204).end();

  const url = process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const teacherKey = process.env.TEACHER_KEY;

  if (!url || !serviceKey) {
    return res.status(500).json({
      ok: false,
      error: "SUPABASE_URL 또는 SUPABASE_SERVICE_ROLE_KEY가 설정되지 않았습니다.",
    });
  }
  if (!teacherKey) {
    return res.status(500).json({ ok: false, error: "TEACHER_KEY가 설정되지 않았습니다." });
  }

  /* 교사 코드 검증 — 서버에서 판정하므로 프런트 소스를 열어도 뚫리지 않는다 */
  const given = String((req.query && req.query.key) || "");
  if (given !== teacherKey) {
    return res.status(200).json({ ok: false, error: "unauthorized" });
  }

  try {
    /* PostgREST 직접 호출 — supabase-js 를 서버에 또 설치할 필요가 없다 */
    const q = new URLSearchParams({
      select: "*",
      order: "created_at.desc",
      limit: "500",
    });
    const r = await fetch(`${url}/rest/v1/five_eyes_results?${q}`, {
      headers: {
        apikey: serviceKey,
        Authorization: `Bearer ${serviceKey}`,
      },
    });

    if (!r.ok) {
      const t = await r.text();
      console.error("results: Supabase 조회 실패", r.status, t.slice(0, 300));
      return res.status(r.status).json({ ok: false, error: "데이터 조회에 실패했습니다." });
    }

    const rows = await r.json();

    /* 같은 학생이 여러 번 제출했으면 가장 마지막 것만 남긴다 */
    const seen = new Set();
    const latest = [];
    for (const row of rows) {
      const k = `${row.sid}_${row.name}`;
      if (seen.has(k)) continue;
      seen.add(k);
      latest.push(row);
    }

    /* 교사 대시보드가 바로 쓸 수 있는 모양으로 평탄화 */
    const shaped = latest.map((r0) => {
      const a = r0.analytics || {};
      return {
        ...a,
        id: r0.id,
        sessionId: r0.session_id || String(r0.id),
        sid: r0.sid,
        name: r0.name,
        nick: r0.nick,
        clearedThinkers: r0.cleared_thinkers,
        challengeTitle: r0.conflict_title,
        challengeLevel: r0.conflict_level || a.challengeLevel || 0,
        tilt: r0.tilt_value,
        stage3Text: r0.stage3_text,
        level1: r0.level1,
        level2: r0.level2,
        record: r0.record_text,
        praise: r0.praise_text,
        createdAt: r0.created_at,
        alerts: Array.isArray(a.alerts) ? a.alerts : [],
      };
    });

    return res.status(200).json({
      ok: true,
      rows: shaped,
      total: rows.length,
      generatedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.error("results: 예외", String(err));
    return res.status(502).json({ ok: false, error: "조회 중 오류가 발생했습니다." });
  }
}

import React, { useState, useEffect, useMemo } from "react";

/* ═══════════════════════════════════════════════════════════════
   TeacherDashboard.jsx — 처방적 관찰 단서 대시보드 (요구사항 4)
   ───────────────────────────────────────────────────────────────
   설계 의도
   · 교사가 이 화면을 여는 순간은 대개 "다음 차시 직전 5분"이다.
     그래서 정렬 1순위를 '지금 개입이 필요한 학생'으로 고정하고,
     잘한 학생 통계는 아래로 내렸다.
   · 모든 알림 카드는 [무슨 일이] [어떤 개념에서] [무엇을 할지]
     세 줄을 함께 보여 준다. 진단만 있고 처방이 없으면 쓸모가 없다.
   ═══════════════════════════════════════════════════════════════ */

const THINKER_LABEL = {
  rawls: "롤스", nozick: "노직", macintyre: "매킨타이어",
  sandel: "샌델", walzer: "왈처",
};
const TL = (id) => THINKER_LABEL[id] || id || "-";
const mmss = (ms) => {
  const s = Math.round((ms || 0) / 1000);
  return `${Math.floor(s / 60)}분 ${String(s % 60).padStart(2, "0")}초`;
};
const pct = (v) => `${Math.round((v || 0) * 100)}%`;

/* ── 스캐폴딩 소거 꺾은선 그래프 (요구사항 3) ─────────────────
   외부 차트 라이브러리 없이 SVG로 직접 그린다. 의존성을 늘리지
   않는 편이 학교 환경에서 배포·유지에 유리하다. */
function FadeChart({ buckets, width = 460, height = 170, color = "#5B45F0", compareRate = null }) {
  if (!buckets || buckets.length < 2) {
    return <div className="dash-empty sm">시도 횟수가 적어 추이를 그릴 수 없습니다.</div>;
  }
  const pad = { t: 14, r: 14, b: 30, l: 38 };
  const w = width - pad.l - pad.r;
  const h = height - pad.t - pad.b;
  const x = (i) => pad.l + (buckets.length === 1 ? w / 2 : (i / (buckets.length - 1)) * w);
  const y = (r) => pad.t + h - r * h;
  const pts = buckets.map((b, i) => [x(i), y(b.rate)]);
  const line = pts.map((p, i) => `${i ? "L" : "M"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
  const area = `${line} L${pts[pts.length - 1][0].toFixed(1)},${pad.t + h} L${pts[0][0].toFixed(1)},${pad.t + h} Z`;

  return (
    <svg className="fade-chart" viewBox={`0 0 ${width} ${height}`} role="img"
      aria-label="문장 예시 의존율 추이">
      {[0, 0.5, 1].map((g) => (
        <g key={g}>
          <line x1={pad.l} y1={y(g)} x2={pad.l + w} y2={y(g)} stroke="#E6E4DE" strokeWidth="1"
            strokeDasharray={g === 0 ? "0" : "3 3"} />
          <text x={pad.l - 8} y={y(g) + 4} textAnchor="end" className="ax">{g * 100}%</text>
        </g>
      ))}
      {compareRate !== null && (
        <g>
          <line x1={pad.l} y1={y(compareRate)} x2={pad.l + w} y2={y(compareRate)}
            stroke="#9AA0C4" strokeWidth="1.5" strokeDasharray="6 4" />
          <text x={pad.l + w} y={y(compareRate) - 6} textAnchor="end" className="ax cmp">
            학급 평균 {pct(compareRate)}
          </text>
        </g>
      )}
      <path d={area} fill={color} opacity="0.09" />
      <path d={line} fill="none" stroke={color} strokeWidth="2.5"
        strokeLinecap="round" strokeLinejoin="round" />
      {pts.map((p, i) => (
        <g key={i}>
          <circle cx={p[0]} cy={p[1]} r="4.5" fill="#fff" stroke={color} strokeWidth="2.5" />
          <text x={p[0]} y={pad.t + h + 18} textAnchor="middle" className="ax">
            {buckets[i].label}
          </text>
        </g>
      ))}
    </svg>
  );
}

/* ── 개별 알림 카드 ── */
function AlertCard({ a }) {
  return (
    <div className={`alert-card ${a.severity}`}>
      <div className="ac-head">
        <span className="ac-badge">{a.severity === "high" ? "🔴 즉시 개입" : "🟡 관찰 필요"}</span>
        <b>{a.label}</b>
      </div>
      <div className="ac-detail">📉 {a.detail}</div>
      <div className="ac-action"><b>처방</b> {a.action}</div>
    </div>
  );
}

/* ── 학생 요약 카드 ── */
function StudentCard({ s, open, onToggle, classAvgLate }) {
  const high = s.alerts.filter((a) => a.severity === "high").length;
  const mid = s.alerts.length - high;
  const fadeOk = s.scaffoldFadeDelta > 0.15;

  return (
    <div className={`stu-card ${high ? "danger" : mid ? "warn" : ""}`}>
      <button className="sc-head" onClick={onToggle}>
        <div className="sc-id">
          <b>{s.name}</b>
          <span className="sc-sid">{s.sid}</span>
        </div>
        <div className="sc-badges">
          {high > 0 && <span className="bdg red">🔴 {high}</span>}
          {mid > 0 && <span className="bdg yellow">🟡 {mid}</span>}
          {s.challengeCompleted && s.challengeLevel === 3 && <span className="bdg gold">🔥 심화 완수</span>}
          {fadeOk && <span className="bdg green">📈 예시 의존 감소</span>}
          {!s.alerts.length && !fadeOk && <span className="bdg gray">특이사항 없음</span>}
        </div>
        <span className="sc-caret">{open ? "▲" : "▼"}</span>
      </button>

      <div className="sc-metrics">
        <div><span>대화 턴</span><b>{s.turnCount}</b></div>
        <div><span>선택 번복</span><b>{s.switchCount}회</b></div>
        <div><span>최장 지연</span><b>{mmss(s.maxDwellMs)}</b></div>
        <div><span>힌트</span><b>{s.hintUsed}/3</b></div>
        <div><span>도전성</span><b>{s.challengeScore}점</b></div>
      </div>

      {open && (
        <div className="sc-body">
          {s.alerts.length > 0 && (
            <div className="sc-sec">
              <h4>🚨 처방적 관찰 단서</h4>
              {s.alerts.map((a) => <AlertCard key={a.id} a={a} />)}
            </div>
          )}

          <div className="sc-sec">
            <h4>📊 스캐폴딩 점진적 소거 추이</h4>
            <p className="sc-cap">
              문장 완성형 예시 버튼에 의존한 비율입니다. 선이 내려갈수록 스스로 설명하기
              시작했다는 뜻이며, 수동적 단계에서 상호작용적 단계로 도약한 증거로 봅니다.
            </p>
            <FadeChart buckets={s.scaffoldBuckets} compareRate={classAvgLate} />
            <div className="fade-read">
              전반 <b>{pct(s.scaffoldEarlyRate)}</b> → 후반 <b>{pct(s.scaffoldLateRate)}</b>
              <span className={`delta ${s.scaffoldFadeDelta > 0 ? "up" : "down"}`}>
                {s.scaffoldFadeDelta > 0
                  ? `▼ ${pct(s.scaffoldFadeDelta)} 감소 — 자립도 상승`
                  : `▲ ${pct(-s.scaffoldFadeDelta)} 증가 — 의존 지속`}
              </span>
            </div>
          </div>

          <div className="sc-sec">
            <h4>🧠 사상가별 인지 부하</h4>
            <div className="th-grid">
              {["rawls", "nozick", "macintyre", "sandel", "walzer"].map((t) => {
                const turns = (s.turnsByThinker || {})[t] || 0;
                const hints = (s.hintsByThinker || {})[t] || 0;
                const lvl = turns >= 6 ? "hard" : turns >= 4 ? "mid" : turns > 0 ? "easy" : "none";
                return (
                  <div key={t} className={`th-cell ${lvl}`}>
                    <b>{TL(t)}</b>
                    <span>{turns ? `${turns}턴` : "미도달"}</span>
                    {hints > 0 && <em>힌트 {hints}</em>}
                  </div>
                );
              })}
            </div>
            <p className="sc-cap">
              턴 수가 많을수록 통크의 되묻기가 반복된 지점입니다.
              6턴 이상(빨강)은 개념 자체를 다시 잡아 줘야 하는 신호입니다.
            </p>
          </div>

          {(s.record || s.stage3Text) && (
            <div className="sc-sec">
              <h4>📝 제출 내용</h4>
              {s.stage3Text && (
                <div className="rec-box">
                  <div className="rb-label">3단계 · 학생이 세운 분배 기준</div>
                  <p>{s.stage3Text}</p>
                </div>
              )}
              {s.record && (
                <div className="rec-box seteuk">
                  <div className="rb-label">과목별 세부능력 및 특기사항</div>
                  <p>{s.record}</p>
                  <button className="copy-btn" onClick={() => {
                    navigator.clipboard?.writeText(s.record);
                  }}>📋 세특 문구 복사</button>
                </div>
              )}
            </div>
          )}

          <div className="sc-sec">
            <h4>🔥 2단계 도전 선택</h4>
            <div className="chal-row">
              <span className={`chal-lv lv${s.challengeLevel}`}>
                {"🔥".repeat(s.challengeLevel || 1)} 난이도 {s.challengeLevel || "-"}
              </span>
              <span className="chal-title">{s.challengeTitle || "-"}</span>
              <span className={`chal-done ${s.challengeCompleted ? "yes" : "no"}`}>
                {s.challengeCompleted ? "완수" : "미완수"}
              </span>
            </div>
            <p className="sc-cap">
              쉬운 쟁점을 고를 수도 있는 상황에서 어려운 쟁점을 택하고 끝까지 마쳤다면
              자기관리 역량(도전성)의 관찰 근거가 됩니다.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   대시보드 본체
   ═══════════════════════════════════════════════════════════════ */
export default function TeacherDashboard({ endpoint, teacherKey, initialRows, demo, onExit }) {
  /* 코드 검증은 진입 전(App.jsx의 교사 로그인 화면)에 이미 끝났고,
     그때 받아 둔 데이터를 initialRows 로 넘겨받아 중복 조회를 피한다. */
  const [rows, setRows] = useState(Array.isArray(initialRows) ? initialRows : []);
  const [state, setState] = useState(Array.isArray(initialRows) ? "ready" : "loading");
  const [openId, setOpenId] = useState(null);
  const [filter, setFilter] = useState("alert");   // alert | all | challenge

  async function load() {
    setState("loading");
    try {
      const r = await fetch(`/api/results?key=${encodeURIComponent(teacherKey || "")}`);
      const d = await r.json();
      if (!d || d.ok !== true) { setState("denied"); return; }
      setRows(Array.isArray(d.rows) ? d.rows : []);
      setState("ready");
    } catch (e) { setState("error"); }
  }

  /* 이미 데이터를 들고 들어왔으면 다시 부르지 않는다 (데모 모드 포함) */
  useEffect(() => {
    if (!Array.isArray(initialRows)) load();
    /* eslint-disable-next-line */
  }, []);

  const classAvgLate = useMemo(() => {
    const v = rows.map((r) => r.scaffoldLateRate).filter((x) => typeof x === "number");
    return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null;
  }, [rows]);

  const kpi = useMemo(() => {
    const n = rows.length || 1;
    const alertStu = rows.filter((r) => (r.alerts || []).some((a) => a.severity === "high"));
    return {
      total: rows.length,
      alert: alertStu.length,
      challenge: rows.filter((r) => r.challengeCompleted && r.challengeLevel === 3).length,
      faded: rows.filter((r) => r.scaffoldFadeDelta > 0.15).length,
      avgTurn: Math.round(rows.reduce((a, b) => a + (b.turnCount || 0), 0) / n),
      avgDwell: Math.round(rows.reduce((a, b) => a + (b.avgDwellMs || 0), 0) / n),
    };
  }, [rows]);

  /* 개입 필요 학생을 항상 위로 */
  const sorted = useMemo(() => {
    const score = (r) => {
      const A = r.alerts || [];
      return A.filter((a) => a.severity === "high").length * 10 + A.length;
    };
    let list = [...rows].sort((a, b) => score(b) - score(a));
    if (filter === "alert") list = list.filter((r) => (r.alerts || []).length > 0);
    if (filter === "challenge") list = list.filter((r) => r.challengeLevel === 3);
    return list;
  }, [rows, filter]);

  /* 어떤 사상가에서 학급 전체가 막혔는지 */
  const classBottleneck = useMemo(() => {
    const agg = {};
    rows.forEach((r) => {
      Object.entries(r.turnsByThinker || {}).forEach(([t, v]) => {
        agg[t] = agg[t] || { turns: 0, n: 0, hints: 0 };
        agg[t].turns += v; agg[t].n += 1;
        agg[t].hints += (r.hintsByThinker || {})[t] || 0;
      });
    });
    return Object.entries(agg)
      .map(([t, v]) => ({ t, avg: v.turns / v.n, hints: v.hints, n: v.n }))
      .sort((a, b) => b.avg - a.avg);
  }, [rows]);

  if (state === "loading" || state === "denied" || state === "error") {
    return (
      <div className="dash">
        <style>{DASH_CSS}</style>
        <div className="dash-gate">
          <div className="dg-card">
            <div className="dg-emoji">{state === "loading" ? "⏳" : "⚠️"}</div>
            <h1>
              {state === "loading" ? "학습 데이터를 불러오는 중" :
               state === "denied" ? "권한을 확인할 수 없습니다" : "연결에 실패했습니다"}
            </h1>
            <p>
              {state === "loading" ? "학생들의 제출 기록을 모으고 있어요." :
               state === "denied" ? "교사 코드가 만료되었거나 올바르지 않습니다." :
               "네트워크 상태를 확인한 뒤 다시 시도해 주세요."}
            </p>
            {state !== "loading" && (
              <button className="dg-btn" onClick={load}>다시 시도</button>
            )}
            {onExit && <button className="dg-back" onClick={onExit}>← 처음으로</button>}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="dash">
      <style>{DASH_CSS}</style>

      <header className="dash-top">
        <b>📋 다섯 사람의 눈 · 처방 대시보드</b>
        <div className="dt-right">
          {!demo && <button className="dt-btn" onClick={load}>↻ 새로고침</button>}
          {onExit && <button className="dt-btn" onClick={onExit}>학생 화면</button>}
        </div>
      </header>

      <main className="dash-wrap">
        {demo && (
          <div className="demo-banner">
            🧪 <b>데모 데이터입니다.</b> 실제 학생 기록이 아니라 화면 구성을 확인하기 위한 예시예요.
            구글 시트를 연결하고 교사 코드로 들어오면 실제 학급 데이터가 표시됩니다.
          </div>
        )}

        {/* ── 학급 KPI ── */}
        <section className="kpi">
          <div className="kpi-cell danger">
            <b>{kpi.alert}</b><span>🔴 즉시 개입 필요</span>
          </div>
          <div className="kpi-cell"><b>{kpi.total}</b><span>제출 학생</span></div>
          <div className="kpi-cell"><b>{kpi.faded}</b><span>📈 예시 의존 감소</span></div>
          <div className="kpi-cell"><b>{kpi.challenge}</b><span>🔥 심화 쟁점 완수</span></div>
          <div className="kpi-cell"><b>{kpi.avgTurn}</b><span>평균 대화 턴</span></div>
          <div className="kpi-cell"><b>{mmss(kpi.avgDwell)}</b><span>평균 응답 지연</span></div>
        </section>

        {/* ── 학급 병목 ── */}
        {classBottleneck.length > 0 && (
          <section className="panel">
            <h3>🧭 다음 차시에 다시 다뤄야 할 개념</h3>
            <p className="p-cap">사상가별 평균 대화 턴 수입니다. 막대가 길수록 학급 전체가 오래 헤맨 지점입니다.</p>
            <div className="bneck">
              {classBottleneck.map((b) => {
                const max = classBottleneck[0].avg || 1;
                return (
                  <div key={b.t} className="bn-row">
                    <span className="bn-name">{TL(b.t)}</span>
                    <div className="bn-track">
                      <div className="bn-fill" style={{
                        width: `${(b.avg / max) * 100}%`,
                        background: b.avg >= 5 ? "#DC2626" : b.avg >= 3.5 ? "#F59E0B" : "#10B981",
                      }} />
                    </div>
                    <span className="bn-val">{b.avg.toFixed(1)}턴 · 힌트 {b.hints}</span>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* ── 필터 ── */}
        <div className="filters">
          {[["alert", "🚨 개입 필요"], ["all", "전체 학생"], ["challenge", "🔥 심화 선택"]].map(([k, l]) => (
            <button key={k} className={filter === k ? "on" : ""} onClick={() => setFilter(k)}>{l}</button>
          ))}
          <span className="f-count">{sorted.length}명</span>
        </div>

        {sorted.length === 0 && <div className="dash-empty">해당하는 학생이 없습니다.</div>}

        <div className="stu-list">
          {sorted.map((s) => (
            <StudentCard key={s.sessionId || s.sid} s={s}
              open={openId === (s.sessionId || s.sid)}
              onToggle={() => setOpenId(openId === (s.sessionId || s.sid) ? null : (s.sessionId || s.sid))}
              classAvgLate={classAvgLate} />
          ))}
        </div>
      </main>
    </div>
  );
}

const DASH_CSS = `
@import url('https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable-dynamic-subset.css');
.dash{--bg:#F5F6F8;--card:#fff;--ink:#191B23;--muted:#6E7383;--line:#E4E6EB;--brand:#5B45F0;
  --red:#DC2626;--amber:#F59E0B;--green:#10B981;
  font-family:'Pretendard Variable',Pretendard,-apple-system,system-ui,sans-serif;
  background:var(--bg);color:var(--ink);min-height:100vh;-webkit-font-smoothing:antialiased}
.dash *{box-sizing:border-box}
.dash button{font-family:inherit;cursor:pointer}

.dash-gate{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
.dg-card{background:#fff;border:1px solid var(--line);border-radius:20px;padding:32px;max-width:380px;width:100%;text-align:center}
.dg-emoji{font-size:38px}
.dg-card h1{font-size:21px;font-weight:900;margin:10px 0 6px}
.dg-card p{font-size:13px;color:var(--muted);font-weight:600;margin:0 0 18px;line-height:1.7}
.dg-card input{width:100%;border:2px solid var(--line);border-radius:12px;padding:14px;font-size:15px;
  font-family:inherit;font-weight:600;margin-bottom:10px}
.dg-card input:focus{border-color:var(--brand);outline:none}
.dg-btn{width:100%;padding:15px;border:none;border-radius:12px;background:var(--brand);color:#fff;font-size:15.5px;font-weight:800}
.dg-btn:disabled{background:#D5D3CD;cursor:not-allowed}
.dg-err{margin-top:10px;font-size:13px;font-weight:700;color:var(--red)}
.dg-back{margin-top:14px;background:none;border:none;font-size:13px;font-weight:700;color:var(--muted)}

.dash-top{position:sticky;top:0;z-index:10;display:flex;align-items:center;padding:13px 20px;
  background:rgba(245,246,248,.94);backdrop-filter:blur(8px);border-bottom:1px solid var(--line);font-size:15px}
.dt-right{margin-left:auto;display:flex;gap:8px}
.dt-btn{font-size:12.5px;font-weight:800;background:#fff;border:1px solid var(--line);border-radius:999px;padding:8px 14px;color:var(--ink)}
.dt-btn:hover{border-color:var(--brand);color:var(--brand)}
.dash-wrap{max-width:960px;margin:0 auto;padding:20px}
.demo-banner{background:#FEF9E7;border:1.5px dashed #E9C46A;border-radius:13px;padding:13px 16px;
  font-size:13px;font-weight:600;color:#7A5A00;line-height:1.7;margin-bottom:16px}
.demo-banner b{font-weight:900}

.kpi{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-bottom:16px}
.kpi-cell{background:#fff;border:1px solid var(--line);border-radius:14px;padding:15px;text-align:center}
.kpi-cell b{display:block;font-size:26px;font-weight:900;letter-spacing:-.02em}
.kpi-cell span{display:block;font-size:11.5px;color:var(--muted);font-weight:700;margin-top:3px}
.kpi-cell.danger{background:#FEF2F2;border-color:#FCA5A5}
.kpi-cell.danger b{color:var(--red)}

.panel{background:#fff;border:1px solid var(--line);border-radius:16px;padding:19px;margin-bottom:16px}
.panel h3{font-size:15.5px;font-weight:900;margin:0 0 4px}
.p-cap{font-size:12.5px;color:var(--muted);font-weight:600;margin:0 0 14px;line-height:1.6}
.bneck{display:grid;gap:9px}
.bn-row{display:flex;align-items:center;gap:10px}
.bn-name{flex:0 0 74px;font-size:13px;font-weight:800}
.bn-track{flex:1;height:12px;background:#F1F2F5;border-radius:99px;overflow:hidden}
.bn-fill{height:100%;border-radius:99px;transition:width .5s}
.bn-val{flex:0 0 118px;text-align:right;font-size:11.5px;font-weight:700;color:var(--muted)}

.filters{display:flex;gap:7px;align-items:center;margin-bottom:12px;flex-wrap:wrap}
.filters button{font-size:13px;font-weight:800;background:#fff;border:1.5px solid var(--line);
  border-radius:999px;padding:9px 15px;color:var(--muted)}
.filters button.on{background:var(--ink);border-color:var(--ink);color:#fff}
.f-count{margin-left:auto;font-size:12.5px;font-weight:700;color:var(--muted)}

.stu-list{display:grid;gap:11px}
.stu-card{background:#fff;border:1.5px solid var(--line);border-radius:16px;overflow:hidden}
.stu-card.danger{border-color:#FCA5A5;box-shadow:0 0 0 3px rgba(220,38,38,.07)}
.stu-card.warn{border-color:#FCD9A5}
.sc-head{width:100%;display:flex;align-items:center;gap:11px;padding:15px 17px;background:none;border:none;text-align:left}
.sc-id b{font-size:15.5px;font-weight:900}
.sc-sid{font-size:12px;color:var(--muted);font-weight:700;margin-left:7px}
.sc-badges{display:flex;gap:5px;flex-wrap:wrap;margin-left:auto}
.bdg{font-size:11px;font-weight:900;border-radius:999px;padding:5px 10px}
.bdg.red{background:#FEE2E2;color:var(--red)}
.bdg.yellow{background:#FEF3C7;color:#B45309}
.bdg.gold{background:#FFF4D6;color:#A16207;border:1px solid #F5D67E}
.bdg.green{background:#DCFCE7;color:#15803D}
.bdg.gray{background:#F1F2F5;color:var(--muted)}
.sc-caret{font-size:11px;color:var(--muted)}
.sc-metrics{display:grid;grid-template-columns:repeat(5,1fr);gap:1px;background:var(--line);border-top:1px solid var(--line)}
.sc-metrics div{background:#FAFAFB;padding:11px 8px;text-align:center}
.sc-metrics span{display:block;font-size:10.5px;color:var(--muted);font-weight:700}
.sc-metrics b{display:block;font-size:15px;font-weight:900;margin-top:3px}
.sc-body{padding:18px;border-top:1px solid var(--line);background:#FCFCFD}
.sc-sec{margin-bottom:20px}
.sc-sec:last-child{margin-bottom:0}
.sc-sec h4{font-size:14px;font-weight:900;margin:0 0 7px}
.sc-cap{font-size:12px;color:var(--muted);font-weight:600;line-height:1.7;margin:8px 0 0}

.alert-card{border-radius:13px;padding:14px;margin-bottom:9px}
.alert-card.high{background:#FEF2F2;border:1.5px solid #FCA5A5}
.alert-card.mid{background:#FFFBEB;border:1.5px solid #FCD9A5}
.ac-head{display:flex;align-items:center;gap:9px;margin-bottom:8px}
.ac-badge{font-size:11px;font-weight:900;background:#fff;border-radius:999px;padding:4px 10px}
.ac-head b{font-size:14.5px;font-weight:900}
.ac-detail{font-size:13px;font-weight:700;color:#44484F;margin-bottom:7px;line-height:1.6}
.ac-action{font-size:13px;font-weight:600;color:#1F2937;line-height:1.7;background:#fff;
  border-radius:9px;padding:10px 12px}
.ac-action b{font-weight:900;margin-right:6px;color:var(--brand)}

.fade-chart{width:100%;height:auto;display:block;background:#fff;border:1px solid var(--line);border-radius:12px}
.fade-chart .ax{font-size:10px;fill:#9AA0C4;font-weight:700}
.fade-chart .ax.cmp{font-size:9.5px;fill:#7C82AB}
.fade-read{margin-top:9px;font-size:13px;font-weight:700;display:flex;gap:9px;align-items:center;flex-wrap:wrap}
.fade-read b{font-weight:900}
.delta{font-size:12px;font-weight:900;border-radius:999px;padding:5px 11px}
.delta.up{background:#DCFCE7;color:#15803D}
.delta.down{background:#FEE2E2;color:var(--red)}

.th-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:7px}
.th-cell{border-radius:11px;padding:11px 7px;text-align:center;border:1.5px solid var(--line);background:#fff}
.th-cell b{display:block;font-size:12.5px;font-weight:900}
.th-cell span{display:block;font-size:11px;color:var(--muted);font-weight:700;margin-top:3px}
.th-cell em{display:block;font-style:normal;font-size:10px;font-weight:800;color:#B45309;margin-top:2px}
.th-cell.hard{background:#FEF2F2;border-color:#FCA5A5}
.th-cell.mid{background:#FFFBEB;border-color:#FCD9A5}
.th-cell.easy{background:#F0FDF4;border-color:#A7E8C4}
.th-cell.none{opacity:.5}

.rec-box{background:#fff;border:1px solid var(--line);border-radius:11px;padding:13px;margin-bottom:9px}
.rec-box.seteuk{background:#F7F5FF;border-color:#D9D2FF}
.rb-label{font-size:11px;font-weight:900;color:var(--brand);margin-bottom:6px}
.rec-box p{margin:0;font-size:13px;line-height:1.8;color:#2B2F3A;font-weight:500;white-space:pre-wrap}
.copy-btn{margin-top:9px;font-size:11.5px;font-weight:800;background:#fff;border:1px solid var(--line);
  border-radius:8px;padding:6px 11px;color:var(--brand)}
.copy-btn:hover{border-color:var(--brand)}
.chal-row{display:flex;align-items:center;gap:10px;flex-wrap:wrap;background:#fff;
  border:1px solid var(--line);border-radius:11px;padding:12px}
.chal-lv{font-size:12.5px;font-weight:900}
.chal-lv.lv3{color:#DC2626} .chal-lv.lv2{color:#D97706} .chal-lv.lv1{color:#059669}
.chal-title{font-size:13.5px;font-weight:700}
.chal-done{margin-left:auto;font-size:11.5px;font-weight:900;border-radius:999px;padding:5px 11px}
.chal-done.yes{background:#DCFCE7;color:#15803D}
.chal-done.no{background:#F1F2F5;color:var(--muted)}

.dash-empty{background:#fff;border:2px dashed var(--line);border-radius:14px;padding:34px;
  text-align:center;font-size:14px;font-weight:700;color:var(--muted)}
.dash-empty.sm{padding:18px;font-size:12.5px;border-width:1px}

@media (max-width:680px){
  .sc-metrics{grid-template-columns:repeat(3,1fr)}
  .th-grid{grid-template-columns:repeat(3,1fr)}
  .sc-badges{width:100%;margin-left:0;order:3}
}
`;

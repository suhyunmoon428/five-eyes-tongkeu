/* ═══════════════════════════════════════════════════════════════
   /api/chat — OpenRouter 프록시 (Vercel Serverless Function)
   ───────────────────────────────────────────────────────────────
   브라우저가 OpenRouter 를 직접 부르면 API 키가 그대로 노출됩니다.
   이 함수가 대신 호출하고, 키는 서버 환경변수에만 존재합니다.

        학생 브라우저 ──▶ /api/chat ──▶ openrouter.ai
                        (키 없음)      (키는 여기서만)
   ═══════════════════════════════════════════════════════════════ */

const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";
const DEFAULT_MODEL = "anthropic/claude-3.5-sonnet";
const MAX_TOKENS_CAP = 1500;

export default async function handler(req, res) {
  // CORS (같은 도메인에서 부르므로 최소한만)
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");

  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") {
    return res.status(405).json({ error: "POST만 허용됩니다." });
  }

  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) {
    console.error("chat: OPENROUTER_API_KEY 환경변수가 비어 있음");
    return res.status(500).json({
      error: "OPENROUTER_API_KEY가 설정되지 않았습니다. 배포 환경변수를 확인하세요.",
    });
  }

  let body = req.body;
  if (typeof body === "string") {
    try { body = JSON.parse(body); } catch (e) { body = {}; }
  }

  const { system, messages, max_tokens, model } = body || {};
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: "messages가 필요합니다." });
  }

  /* OpenRouter는 OpenAI 형식이므로 system을 messages 맨 앞에 넣는다 */
  const payload = {
    model: model || process.env.OPENROUTER_MODEL || DEFAULT_MODEL,
    max_tokens: Math.min(Number(max_tokens) || 1000, MAX_TOKENS_CAP),
    messages: [
      ...(system ? [{ role: "system", content: String(system) }] : []),
      ...messages.map((m) => ({ role: m.role, content: m.content })),
    ],
  };

  try {
    const upstream = await fetch(OPENROUTER_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
        // OpenRouter 순위 노출용 (선택) — 배포 주소로 바꾸면 됩니다
        "HTTP-Referer": process.env.SITE_URL || "https://five-eyes.vercel.app",
        "X-Title": "Five Eyes - Tongkeu",
      },
      body: JSON.stringify(payload),
    });

    const data = await upstream.json();

    if (!upstream.ok) {
      console.error("chat: OpenRouter 오류", upstream.status, JSON.stringify(data).slice(0, 300));
      return res.status(upstream.status).json({
        error: data?.error?.message || "OpenRouter 호출에 실패했습니다.",
      });
    }

    return res.status(200).json(data);
  } catch (err) {
    console.error("chat: 업스트림 연결 실패", String(err));
    return res.status(502).json({ error: "OpenRouter 연결에 실패했습니다: " + String(err) });
  }
}
